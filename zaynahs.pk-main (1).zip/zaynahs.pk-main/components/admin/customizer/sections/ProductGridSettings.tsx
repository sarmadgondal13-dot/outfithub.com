'use client';

import React from 'react';
import { SHOP_CATEGORY_ID } from '@/lib/config/singleton-ids';
import { HomepageSection, Category, Product } from '@/lib/types';
import ManualProductPicker from './product-grid/ManualProductPicker';
import BottomGridActions from './product-grid/BottomGridActions';
import ResponsiveProductsPerPageControl from '../shared/ResponsiveProductsPerPageControl';
import ResponsiveGridColumnsControl from '../shared/ResponsiveGridColumnsControl';
import GridGapControl from '../shared/GridGapControl';
import ContentWidthControl from '../shared/ContentWidthControl';
import FillRowsControl from '../shared/FillRowsControl';
import CatalogLimitControl from '../shared/CatalogLimitControl';
import GridLimitControl from '../shared/GridLimitControl';
import SectionSpacingControls from '../shared/SectionSpacingControls';
import { AccordionGroup } from '@/components/admin/customizer/controls';
import { Grid2X2, Play } from '@/components/common/Icons';

interface ProductGridSettingsProps {
  section: HomepageSection;
  categories: Category[];
  products?: Product[];
  viewportMode?: 'desktop' | 'tablet' | 'mobile';
  onUpdateSection: (updates: Partial<HomepageSection>) => void;
}

export default function ProductGridSettings({
  section,
  categories,
  products = [],
  viewportMode = 'desktop',
  onUpdateSection
}: ProductGridSettingsProps) {
  const settings = section.settings || {};

  const handleSettingsChange = (key: string, value: unknown) => {
    onUpdateSection({
      settings: { ...settings, [key]: value }
    });
  };

  const sortMethod = settings.sortMethod || (settings.source === 'featured' ? 'featured' : settings.source && settings.source !== 'all' ? 'category' : 'all');
  const manualProductIds: string[] = settings.manualProductIds || [];

  return (
    <div className="space-y-3">
      <AccordionGroup id={`pg-${section.id}-content`} title="Content & Source" defaultOpen>
      <div className="space-y-4 pt-2">
      {/* Show/Hide Section Title Toggle */}
      <div className="flex justify-between items-center border-b border-gray-200 dark:border-gray-800 pb-2.5">
        <div>
          <span className="text-xs font-bold text-gray-700 dark:text-gray-300 block">Show Section Title</span>
          <span className="text-[10px] text-gray-400">Display product grid title heading</span>
        </div>
        <label className="relative inline-flex items-center cursor-pointer select-none">
          <input
            type="checkbox"
            checked={settings.show_title !== false}
            onChange={(e) => handleSettingsChange('show_title', e.target.checked)}
            className="sr-only peer"
          />
          <div className="w-10 h-5 bg-gray-200 dark:bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#e94560]" />
        </label>
      </div>
      <div className="space-y-1.5">
        <label className="text-[11px] font-bold text-gray-500 dark:text-gray-400">
          Product Source
        </label>
        <select
          value={settings.source || 'all'}
          onChange={e => handleSettingsChange('source', e.target.value)}
          className="w-full px-3 py-2 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-gray-800 rounded-xl text-xs font-semibold focus:outline-none focus:border-[#e94560] text-gray-900 dark:text-white"
        >
          <option value="all">All Products</option>
          <option value="featured">Featured Products Only</option>
          {categories.filter(cat => cat.slug !== 'shop' && cat.id !== SHOP_CATEGORY_ID).map(cat => (
            <option key={cat.id} value={cat.id}>
              Category: {cat.name}
            </option>
          ))}
        </select>
      </div>

      <hr className="border-gray-200 dark:border-gray-800" />

      <div className="space-y-1.5">
        <label className="text-[11px] font-bold text-gray-500 dark:text-gray-400">
          Sort Method
        </label>
        <select
          value={sortMethod}
          onChange={e => {
            handleSettingsChange('sortMethod', e.target.value);
            if (e.target.value === 'manual' && !settings.manualProductIds) {
              handleSettingsChange('manualProductIds', []);
            }
          }}
          className="w-full px-3 py-2 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-gray-800 rounded-xl text-xs font-semibold focus:outline-none focus:border-[#e94560] text-gray-900 dark:text-white"
        >
          <option value="all">Default (as fetched)</option>
          <option value="manual">Manual Pick &amp; Sort</option>
          <option value="featured">Featured / Most Relevant</option>
          <option value="best_selling">Best Selling</option>
          <option value="recent">Newest First (Recent Added)</option>
          <option value="oldest">Oldest First</option>
          <option value="price_low">Price: Low to High</option>
          <option value="price_high">Price: High to Low</option>
          <option value="a_to_z">A to Z (Name)</option>
          <option value="z_to_a">Z to A (Name)</option>
          <option value="category">Selected Category Order</option>
        </select>
      </div>

      {sortMethod === 'manual' && (
        <ManualProductPicker
          products={products}
          manualProductIds={manualProductIds}
          settingsSource={settings.source}
          onUpdateManualIds={(ids) => handleSettingsChange('manualProductIds', ids)}
        />
      )}

      {/* Limit Mode (Auto = Columns × Rows, Manual = Exact per-device limit) */}
      <div className="space-y-2.5 p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-white/[0.02]">
        <label className="text-[11px] font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider block">
          Limit Mode (Auto / Manual)
        </label>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            onClick={() => handleSettingsChange('limit_mode', 'auto')}
            className={`px-2 py-1.5 rounded-lg border text-center transition-all cursor-pointer ${
              settings.limit_mode === 'auto'
                ? 'border-[#e94560] bg-[#e94560]/10 text-[#e94560] font-black'
                : 'border-gray-200 dark:border-gray-800 text-gray-600 dark:text-gray-300'
            }`}
          >
            <span className="block text-[11px] font-bold">Auto</span>
            <span className="block text-[9px] text-gray-400">Columns × rows</span>
          </button>
          <button
            type="button"
            onClick={() => handleSettingsChange('limit_mode', 'manual')}
            className={`px-2 py-1.5 rounded-lg border text-center transition-all cursor-pointer ${
              settings.limit_mode !== 'auto'
                ? 'border-[#e94560] bg-[#e94560]/10 text-[#e94560] font-black'
                : 'border-gray-200 dark:border-gray-800 text-gray-600 dark:text-gray-300'
            }`}
          >
            <span className="block text-[11px] font-bold">Manual</span>
            <span className="block text-[9px] text-gray-400">Exact number</span>
          </button>
        </div>

        {settings.limit_mode === 'auto' ? (
          <div className="space-y-1 pt-1">
            <div className="flex justify-between text-[10px] text-gray-500 font-semibold">
              <span>Rows to show</span>
              <span className="text-[#e94560] font-bold">
                {Number(settings.columns_desktop) || 4} cols × {Number(settings.limit_rows) || 2} rows = {(Number(settings.columns_desktop) || 4) * (Number(settings.limit_rows) || 2)}
              </span>
            </div>
            <select
              value={Number(settings.limit_rows) || 2}
              onChange={(e) => handleSettingsChange('limit_rows', Number(e.target.value))}
              className="w-full px-3 py-2 bg-white dark:bg-[#16162a] border border-gray-200 dark:border-gray-800 rounded-xl text-xs font-semibold focus:outline-none focus:border-[#e94560] text-gray-900 dark:text-white"
            >
              {[1, 2, 3, 4, 5, 6].map((r) => (
                <option key={r} value={r}>
                  {r} {r === 1 ? 'Row' : 'Rows'}
                </option>
              ))}
            </select>
            <p className="text-[10px] text-gray-400 leading-normal">
              Auto dynamically calculates product count = columns × rows per device.
            </p>
          </div>
        ) : (
          <div className="pt-1">
            <ResponsiveProductsPerPageControl
              label="Products per Page Limit"
              description="Number of products shown initially and per Load More batch for each device."
              viewportMode={viewportMode}
              desktopLimit={Number(settings.products_per_page_desktop) || Number(settings.limit) || 8}
              tabletLimit={Number(settings.products_per_page_tablet) || Number(settings.limit) || 6}
              mobileLimit={Number(settings.products_per_page_mobile) || Number(settings.limit) || 4}
              onChangeDesktop={(val) => {
                onUpdateSection({
                  settings: {
                    ...settings,
                    limit_mode: 'manual',
                    products_per_page_desktop: val,
                    limit: val,
                  }
                });
              }}
              onChangeTablet={(val) => {
                onUpdateSection({
                  settings: {
                    ...settings,
                    limit_mode: 'manual',
                    products_per_page_tablet: val,
                  }
                });
              }}
              onChangeMobile={(val) => {
                onUpdateSection({
                  settings: {
                    ...settings,
                    limit_mode: 'manual',
                    products_per_page_mobile: val,
                  }
                });
              }}
            />
          </div>
        )}
      </div>
      {/* Responsive Columns per Device (Mobile: 1-3, Tablet: 2-4, Desktop: 2-8) */}
      <ResponsiveGridColumnsControl
        label="Product Grid Columns"
        viewportMode={viewportMode}
        mode={settings.columns_mode || 'manual'}
        onChangeMode={(m) => handleSettingsChange('columns_mode', m)}
        minCardDesktop={Number(settings.min_card_desktop) || 220}
        onChangeMinCardDesktop={(px) => handleSettingsChange('min_card_desktop', px)}
        desktopCols={Number(settings.columns_desktop) || 4}
        tabletCols={Number(settings.columns_tablet) || 3}
        mobileCols={Number(settings.columns_mobile) || 2}
        onChangeDesktop={(cols) => handleSettingsChange('columns_desktop', cols)}
        onChangeTablet={(cols) => handleSettingsChange('columns_tablet', cols)}
        onChangeMobile={(cols) => handleSettingsChange('columns_mobile', cols)}
      />

      {/* Grid Gap (Tight, Normal, Relaxed) */}
      <GridGapControl
        value={settings.grid_gap || 'normal'}
        onChange={(gap) => handleSettingsChange('grid_gap', gap)}
      />

      {/* Content Width (Boxed, Wide, Full) */}
      <ContentWidthControl
        value={settings.content_width || 'wide'}
        onChange={(w) => handleSettingsChange('content_width', w)}
      />

      {/* Fill Rows (round up to a full row) */}
      <FillRowsControl
        value={settings.fill_rows !== false}
        onChange={(v) => handleSettingsChange('fill_rows', v)}
      />

      {/* Display Mode: Grid vs Carousel/Slider */}
      <div className="space-y-1.5 pt-2 border-t border-gray-200 dark:border-gray-800">
        <label className="text-[11px] font-bold text-gray-500 dark:text-gray-400">Display Mode</label>
        <div className="grid grid-cols-2 gap-2">
          {(['grid', 'slider'] as const).map((mode) => (
            <button
              key={mode}
              type="button"
              onClick={() => handleSettingsChange('display_mode', mode)}
              className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer capitalize ${
                (settings.display_mode || 'grid') === mode
                  ? 'bg-[#e94560] text-white border-[#e94560]'
                  : 'bg-gray-50 dark:bg-white/5 border-gray-200 dark:border-gray-800 text-gray-700 dark:text-gray-300'
              }`}
            >
              <span className="inline-flex items-center justify-center gap-1.5">{mode === 'grid' ? <Grid2X2 className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}<span className="capitalize">{mode}</span></span>
            </button>
          ))}
        </div>
        {settings.display_mode === 'slider' && (
          <p className="text-[10px] text-gray-400 leading-normal pt-1">
            Slider mode: swipeable horizontal scroll on mobile, arrows on desktop.
          </p>
        )}
      </div>
      </div>
      </AccordionGroup>

      <AccordionGroup id={`pg-${section.id}-actions`} title="View-All & Pagination" defaultOpen={false}>
      <div className="space-y-4 pt-2">
      {/* Upper View All Button Link & Toggle */}
      <div className="space-y-2.5 pb-2 border-b border-gray-200 dark:border-gray-800">
        <div className="flex justify-between items-center">
          <div>
            <span className="text-xs font-bold text-gray-700 dark:text-gray-300 block">Upper View All Link</span>
            <span className="text-[10px] text-gray-400">Link next to grid title header</span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer select-none">
            <input
              type="checkbox"
              checked={settings.show_upper_view_all !== false}
              onChange={(e) => handleSettingsChange('show_upper_view_all', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-10 h-5 bg-gray-200 dark:bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#e94560]" />
          </label>
        </div>

        {settings.show_upper_view_all !== false && (
          <div className="space-y-2 pt-1 pl-2 border-l-2 border-[#e94560]/30">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-gray-500 uppercase">Button Text</label>
              <input
                type="text"
                value={settings.viewAllText || ''}
                onChange={e => handleSettingsChange('viewAllText', e.target.value)}
                placeholder="View All"
                className="w-full px-3 py-1.5 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-gray-800 rounded-xl text-xs font-semibold focus:outline-none focus:border-[#e94560] text-gray-900 dark:text-white"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-gray-500 uppercase">Custom Link URL</label>
              <input
                type="text"
                value={settings.viewAllUrl || ''}
                onChange={e => handleSettingsChange('viewAllUrl', e.target.value)}
                placeholder="e.g. /shop?category=co-ord-sets"
                className="w-full px-3 py-1.5 bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-gray-800 rounded-xl text-xs font-semibold focus:outline-none focus:border-[#e94560] text-gray-900 dark:text-white"
              />
              <p className="text-[10px] text-gray-400 leading-normal">
                If left blank, it will automatically link to the selected category page.
              </p>
            </div>
          </div>
        )}
      </div>

      <BottomGridActions
        settings={settings}
        handleSettingsChange={handleSettingsChange}
        viewportMode={viewportMode}
        hideProductsPerPage={true}
      />
      </div>
      </AccordionGroup>

      <SectionSpacingControls section={section} onUpdateSection={onUpdateSection} />
    </div>
  );
}
