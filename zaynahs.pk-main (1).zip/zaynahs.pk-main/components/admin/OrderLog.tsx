'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import OrderCreateCanvas from '@/components/admin/OrderCreateCanvas';
import AdminSearchInput from '@/components/admin/shared/AdminSearchInput';
import AdminDateFilter from '@/components/admin/shared/AdminDateFilter';
import { Search, TrendingUp, SlidersHorizontal } from '@/components/common/Icons';
import { useHorizontalScroll } from '@/lib/hooks/useHorizontalScroll';
import { Order, StoreSettings, FailedOrderAttempt } from '@/lib/types';

import { OrderLogStatsBar } from './order-log/OrderLogStatsBar';
import { OrderLogBulkActions } from './order-log/OrderLogBulkActions';
import { OrderLogTable } from './order-log/OrderLogTable';
import { FailedAttemptsModal } from './order-log/FailedAttemptsModal';
import { useOrderLogState } from './order-log/hooks/useOrderLogState';

interface OrderLogProps {
  initialOrders: Order[];
  settings: StoreSettings;
  initialFailedAttempts?: FailedOrderAttempt[];
}

export default function OrderLog({ initialOrders, settings, initialFailedAttempts = [] }: OrderLogProps) {
  const o = useOrderLogState({ initialOrders, settings });
  const [isFailedModalOpen, setIsFailedModalOpen] = useState(false);
  const failedAttempts = initialFailedAttempts;
  const { scrollRef: mobileTabsRef, scrollIntoView: scrollMobileTabIntoView } = useHorizontalScroll<HTMLDivElement>();
  const { scrollRef: desktopTabsRef, scrollIntoView: scrollDesktopTabIntoView } = useHorizontalScroll<HTMLDivElement>();

  return (
    <div className={`space-y-6 relative transition-all duration-300 font-sans pb-20 ${o.isFullWidth ? 'max-w-none px-4' : 'max-w-6xl mx-auto'}`}>
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => o.setIsFullWidth(!o.isFullWidth)}
            className="p-1.5 rounded-lg text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            title={o.isFullWidth ? "Collapse view" : "Expand view"}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
              {o.isFullWidth ? (
                <path fillRule="evenodd" d="M12 4a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 11-2 0V6.414l-2.293 2.293a1 1 0 11-1.414-1.414L15 5H13a1 1 0 01-1-1zm-4 12a1 1 0 01-1 1H3a1 1 0 01-1-1v-4a1 1 0 112 0v1.586l2.293-2.293a1 1 0 111.414 1.414L5 13.586V15h2a1 1 0 011 1z" clipRule="evenodd" />
              ) : (
                <path fillRule="evenodd" d="M3 4a1 1 0 011-1h4a1 1 0 010 2H6.414l2.293 2.293a1 1 0 11-1.414 1.414L5 6.414V8a1 1 0 01-2 0V4zm9 1a1 1 0 110-2h4a1 1 0 011 1v4a1 1 0 11-2 0V6.414l-2.293 2.293a1 1 0 11-1.414-1.414L13.586 5H12zm-9 7a1 1 0 112 0v1.586l2.293-2.293a1 1 0 111.414 1.414L6.414 15H8a1 1 0 110 2H4a1 1 0 01-1-1v-4zm13-1a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 110-2h1.586l-2.293-2.293a1 1 0 111.414-1.414L15 13.586V12a1 1 0 011-1z" clipRule="evenodd" />
              )}
            </svg>
          </button>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">Orders</h1>
        </div>

        <div className="flex items-center gap-2 ml-auto">
          {failedAttempts.length > 0 && (
            <button
              onClick={() => setIsFailedModalOpen(true)}
              className="px-3 py-2 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 dark:hover:bg-rose-950/60 text-xs font-bold transition-all border border-rose-200 dark:border-rose-900/50 flex items-center gap-1.5 shadow-xs"
              title="View customers who had errors during checkout"
            >
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              <span>Failed Checkouts</span>
              <span className="px-1.5 py-0.2 rounded-full bg-rose-200 dark:bg-rose-900 text-[10px] font-black">
                {failedAttempts.length}
              </span>
            </button>
          )}

          <button
            onClick={() => o.setIsCreateCanvasOpen(true)}
            className="px-3.5 py-2 rounded-lg bg-[#008060] hover:bg-[#006e52] text-white text-xs font-bold transition-all shadow-xs"
          >
            Create order
          </button>
        </div>
      </div>

      {/* Stats Bar */}
      <OrderLogStatsBar
        orders={o.orders}
        dateFilter={o.dateFilter}
        setDateFilter={o.setDateFilter}
        customStartDate={o.customStartDate}
        customEndDate={o.customEndDate}
        setCustomStartDate={o.setCustomStartDate}
        setCustomEndDate={o.setCustomEndDate}
        settings={settings}
      />

      {/* Customer Filter Active Banner */}
      {o.selectedCustomer && (
        <div className="flex items-center justify-between gap-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 rounded-xl px-4 py-2.5 text-xs text-blue-900 dark:text-blue-200 animate-fade-in shadow-xs">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse shrink-0" />
            <span className="truncate">
              Showing orders for customer: <strong className="font-bold text-blue-950 dark:text-white">{o.selectedCustomer.name || o.selectedCustomer.phone}</strong>
              {o.selectedCustomer.phone && (
                <span className="ml-1 text-[11.5px] text-blue-600 dark:text-blue-400 font-mono">({o.selectedCustomer.phone})</span>
              )}
              <span className="ml-2 text-gray-500 dark:text-gray-400 font-normal">
                ({o.totalRows} {o.totalRows === 1 ? 'order' : 'orders'})
              </span>
            </span>
          </div>
          <button
            type="button"
            onClick={o.clearCustomerFilter}
            className="shrink-0 inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white dark:bg-blue-900/80 text-blue-700 dark:text-blue-200 hover:bg-blue-100 dark:hover:bg-blue-800 text-xs font-bold transition-all shadow-xs cursor-pointer border border-blue-200 dark:border-blue-800"
            title="Clear customer filter and return to all orders"
          >
            <span>✕ Clear filter</span>
          </button>
        </div>
      )}

      {/* Sticky Filter Tabs & Controls Toolbar (Flush with AdminHeader, zero gap) */}
      <div className="sticky top-0 z-20 -mt-3 sm:-mt-4 pt-3 sm:pt-4 -mx-3 sm:-mx-4 md:-mx-5 px-3 sm:px-4 md:px-5 bg-slate-50 dark:bg-[#0c0c16] pb-2">
        {/* Mobile Layout (< md): Native App Smart Controls + Full-Width Pill Tabs */}
        <div className="md:hidden space-y-2">
          {/* Mobile Top Controls Bar */}
          <div className="flex items-center gap-2 bg-white/95 dark:bg-[#16162a]/95 backdrop-blur-md border border-gray-200 dark:border-gray-800 rounded-xl px-2.5 py-1.5 shadow-2xs">
            <button
              type="button"
              onClick={() => o.setIsSearchExpanded(!o.isSearchExpanded)}
              className={`flex-1 flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                o.isSearchExpanded || o.searchQuery
                  ? 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400'
                  : 'bg-gray-50 dark:bg-white/5 border-gray-200 dark:border-gray-800 text-gray-500 dark:text-gray-400'
              }`}
            >
              <Search className="h-3.5 w-3.5 shrink-0 text-gray-400" />
              <span className="truncate">
                {o.searchQuery ? `"${o.searchQuery}"` : 'Search orders...'}
              </span>
              {o.searchQuery && (
                <span
                  onClick={(e) => { e.stopPropagation(); o.setSearchQuery(''); }}
                  className="ml-auto text-[10px] font-bold text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                >
                  ✕
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => o.setIsFiltersExpanded(!o.isFiltersExpanded)}
              className={`h-8 px-2.5 rounded-lg border flex items-center gap-1.5 text-xs font-bold transition-all shrink-0 ${
                o.isFiltersExpanded || o.dateFilter !== 'all' || o.statusFilter !== 'all'
                  ? 'bg-[#e94560]/10 border-[#e94560]/30 text-[#e94560]'
                  : 'bg-gray-50 dark:bg-white/5 border-gray-200 dark:border-gray-800 text-gray-600 dark:text-gray-300'
              }`}
              title="Filters"
            >
              <SlidersHorizontal className="h-3.5 w-3.5" />
              <span>Filters</span>
              {(o.dateFilter !== 'all' || o.statusFilter !== 'all') && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#e94560]" />
              )}
            </button>

            <Link
              href="/admin/reporting"
              className="h-8 w-8 rounded-lg border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-white/5 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white flex items-center justify-center transition-all shrink-0"
              title="View reports"
            >
              <TrendingUp className="h-3.5 w-3.5" />
            </Link>
          </div>

          {/* Mobile Native Horizontal Pill Chips (100% Fluid Touch Pan & Drag, Zero Cutoff) */}
          <div 
            ref={mobileTabsRef}
            className="filter-tabs-scroll flex items-center gap-1.5 overflow-x-auto overflow-y-hidden touch-pan-x overscroll-x-contain [-webkit-overflow-scrolling:touch] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden py-1 px-1 pr-10 cursor-grab active:cursor-grabbing select-none"
            style={{ WebkitOverflowScrolling: 'touch', touchAction: 'pan-x' }}
          >
            {([
              { key: 'all', label: 'All' },
              { key: 'unfulfilled', label: 'Unfulfilled' },
              { key: 'fulfilled', label: 'Fulfilled' },
              { key: 'unpaid', label: 'Unpaid' },
              { key: 'open', label: 'Open' },
              { key: 'archived', label: 'Archived' },
            ] as const).map((tab) => {
              const isActive = o.activeTab === tab.key;
              return (
                <button
                  key={tab.key}
                  type="button"
                  onClick={(e) => { 
                    scrollMobileTabIntoView(e.currentTarget);
                    o.setActiveTab(tab.key); 
                    o.setSelectedOrderIds([]); 
                  }}
                  className={`shrink-0 px-3.5 py-1.5 rounded-full text-xs font-bold transition-all select-none ${
                    isActive
                      ? 'bg-[#e94560] text-white shadow-xs'
                      : 'bg-white dark:bg-[#16162a] text-gray-600 dark:text-gray-300 border border-gray-200/90 dark:border-gray-800'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Desktop Layout (>= md): Classic Unified Header Bar */}
        <div className="hidden md:flex filter-tabs-row items-center gap-2 border border-gray-200 dark:border-gray-800 bg-white/95 dark:bg-[#16162a]/95 backdrop-blur-md rounded-t-xl px-2 sm:px-3 py-1 select-none shadow-xs">
          {/* Scrollable tabs — kept separate from the action icons so tabs never clip */}
          <div 
            ref={desktopTabsRef}
            className="filter-tabs-scroll flex items-center flex-1 min-w-0 overflow-x-auto overflow-y-hidden touch-pan-x overscroll-x-contain [-webkit-overflow-scrolling:touch] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden cursor-grab active:cursor-grabbing select-none pr-4"
          >
            {([
              { key: 'all', label: 'All' },
              { key: 'unfulfilled', label: 'Unfulfilled' },
              { key: 'fulfilled', label: 'Fulfilled' },
              { key: 'unpaid', label: 'Unpaid' },
              { key: 'open', label: 'Open' },
              { key: 'archived', label: 'Archived' },
            ] as const).map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={(e) => { 
                  scrollDesktopTabIntoView(e.currentTarget);
                  o.setActiveTab(tab.key); 
                  o.setSelectedOrderIds([]); 
                }}
                className={`filter-tab shrink-0 whitespace-nowrap px-3 py-2 text-xs sm:text-[13.5px] transition-all font-bold border-b-2 mr-1 sm:mr-2 ${o.activeTab === tab.key
                    ? 'border-[#e94560] text-[#e94560] dark:border-[#e94560] dark:text-[#e94560]'
                    : 'border-transparent text-gray-500 hover:text-gray-900 dark:hover:text-white'
                  }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Right side icons — fixed, never part of the scroll track */}
          <div className="flex items-center gap-1 sm:gap-1.5 py-1 shrink-0">
            <button
              onClick={() => o.setIsSearchExpanded(!o.isSearchExpanded)}
              className={`table-ctrl-btn w-8 h-8 rounded-md border flex items-center justify-center transition-all ${o.isSearchExpanded
                  ? 'bg-gray-100 dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white'
                  : 'bg-white dark:bg-transparent border-gray-200 dark:border-gray-800 text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white'
                }`}
              title="Search"
            >
              <Search className="h-4 w-4" />
            </button>
            <button
              onClick={() => o.setIsFiltersExpanded(!o.isFiltersExpanded)}
              className={`table-ctrl-btn w-8 h-8 rounded-md border flex items-center justify-center transition-all ${o.isFiltersExpanded
                  ? 'bg-gray-100 dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white'
                  : 'bg-white dark:bg-transparent border-gray-200 dark:border-gray-800 text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white'
                }`}
              title="Filters"
            >
              <SlidersHorizontal className="h-4 w-4" />
            </button>

            <Link
              href="/admin/reporting"
              className="table-ctrl-btn w-8 h-8 rounded-md border border-gray-200 dark:border-gray-800 text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white flex items-center justify-center transition-all"
              title="View reports"
            >
              <TrendingUp className="h-4 w-4" />
            </Link>
          </div>
        </div>

        {/* Expanded Search Input */}
        {o.isSearchExpanded && (
          <div className="bg-white/95 dark:bg-[#16162a]/95 backdrop-blur-md border-x border-gray-200 dark:border-gray-800 px-4 py-3 flex gap-2 animate-fade-in border-b shadow-xs">
            <AdminSearchInput
              value={o.searchQuery}
              onChange={o.setSearchQuery}
              placeholder="Search by order no, customer or phone..."
              className="flex-1 w-full"
            />
          </div>
        )}

        {/* Expanded Filters Panel */}
        {o.isFiltersExpanded && (
          <div className="bg-white/95 dark:bg-[#16162a]/95 backdrop-blur-md border-x border-gray-200 dark:border-gray-800 px-4 py-3.5 flex flex-wrap items-center gap-3.5 animate-fade-in border-b shadow-xs">
            <AdminDateFilter
              value={o.dateFilter}
              onChange={o.setDateFilter}
              className="flex-1 sm:flex-initial"
              options={[
                { value: 'today', label: 'Today' },
                { value: 'yesterday', label: 'Yesterday' },
                { value: 'tomorrow', label: 'Tomorrow' },
                { value: 'last7', label: 'Last 7 Days' },
                { value: 'last30', label: 'Last 30 Days' },
                { value: 'custom', label: 'Custom Range' }
              ]}
            />

            <div className="flex items-center gap-1.5 bg-white dark:bg-[#16162a] border border-gray-200 dark:border-gray-800 rounded-xl px-3 py-1 flex-1 sm:flex-initial">
              <select
                value={o.statusFilter}
                onChange={(e) => o.setStatusFilter(e.target.value)}
                className="bg-transparent border-0 text-xs font-bold focus:outline-none text-gray-900 dark:text-white cursor-pointer py-1.5"
              >
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="placed">Placed</option>
                <option value="confirmed">Confirmed</option>
                <option value="processing">Processing</option>
                <option value="shipped">Shipped</option>
                <option value="out_for_delivery">Out for Delivery</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
                <option value="refunded">Refunded</option>
              </select>
            </div>

            {o.dateFilter === 'custom' && (
              <div className="flex items-center gap-2 bg-gray-50 dark:bg-gray-800 px-3 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700 ml-auto w-full sm:w-auto mt-2 sm:mt-0">
                <span className="text-[10px] font-bold text-gray-400 uppercase">Range:</span>
                <input
                  type="date"
                  value={o.customStartDate}
                  onChange={(e) => o.setCustomStartDate(e.target.value)}
                  className="bg-transparent border-0 text-xs font-bold text-gray-900 dark:text-white focus:outline-none"
                />
                <span className="text-gray-400">—</span>
                <input
                  type="date"
                  value={o.customEndDate}
                  onChange={(e) => o.setCustomEndDate(e.target.value)}
                  className="bg-transparent border-0 text-xs font-bold text-gray-900 dark:text-white focus:outline-none"
                />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bulk Actions Panel Overlay */}
      <OrderLogBulkActions
        selectedOrderIds={o.selectedOrderIds}
        setSelectedOrderIds={o.setSelectedOrderIds}
        handleBulkFulfil={o.handleBulkFulfil}
        handleBulkUnfulfil={o.handleBulkUnfulfil}
        handleBulkCancel={o.handleBulkCancel}
        handleBulkTrash={o.handleBulkDelete}
      />

      {/* Main Table Layout */}
      <OrderLogTable
        sortedOrders={o.sortedOrders}
        selectedOrderIds={o.selectedOrderIds}
        setSelectedOrderIds={o.setSelectedOrderIds}
        visibleColumns={o.visibleColumns}
        settings={settings}
        rowsPerPage={o.rowsPerPage}
        currentPage={o.currentPage}
        totalRows={o.totalRows}
        handleRowsPerPageChange={o.handleRowsPerPageChange}
        goToPage={o.goToPage}
      />

      {/* Hide scrollbar styling */}
      <style dangerouslySetInnerHTML={{
        __html: `
        .filter-tabs-scroll::-webkit-scrollbar {
          display: none;
        }
        .filter-tabs-scroll {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      ` }} />

      {/* Order Creator Canvas Drawer */}
      <OrderCreateCanvas
        isOpen={o.isCreateCanvasOpen}
        onClose={() => o.setIsCreateCanvasOpen(false)}
        onOrderCreated={(newOrder) => {
          // Will be refetched by realtime or callback
        }}
        settings={settings}
      />

      {/* Failed Attempts Recovery Modal */}
      <FailedAttemptsModal
        open={isFailedModalOpen}
        onClose={() => setIsFailedModalOpen(false)}
        failedAttempts={failedAttempts}
        settings={settings}
      />
    </div>
  );
}
