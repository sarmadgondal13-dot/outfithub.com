'use client';

import React from 'react';
import { MediaItem } from './hooks/useMediaManagerData';
import { Check, Play, Eye, Copy, Edit, Trash2, CheckCircle2, Loader2, Zap, X, Sparkles, Clock } from '@/components/common/Icons';

interface MediaCardProps {
  item: MediaItem;
  index?: number;
  isSelected: boolean;
  onToggle: () => void;
  mode: 'library' | 'selector';
  generatingId: string | null;
  bulkGenerating: boolean;
  bulkCompletedIds: string[];
  bulkFailedIds: string[];
  setPreviewItem: (item: MediaItem) => void;
  handleCopyUrl: (url: string) => void;
  setEditingItem: (item: MediaItem | null) => void;
  handleDelete: (id: string, url: string) => void;
  handleSingleGenerate: (item: MediaItem) => void;
  formatBytes: (bytes?: number) => string;
  showCheckbox?: boolean;
  showBadge?: boolean;
  showActions?: boolean;
  isLastActive?: boolean;
  lastActiveType?: 'viewed' | 'edited' | null;
  hasSelection?: boolean;
}

export function MediaCard({
  item,
  index,
  isSelected,
  onToggle,
  mode,
  generatingId,
  bulkGenerating,
  bulkCompletedIds,
  bulkFailedIds,
  setPreviewItem,
  handleCopyUrl,
  setEditingItem,
  handleDelete,
  handleSingleGenerate,
  formatBytes,
  showCheckbox = true,
  showBadge = true,
  showActions = true,
  isLastActive = false,
  lastActiveType = null,
  hasSelection = false,
}: MediaCardProps) {
  const [imageLoaded, setImageLoaded] = React.useState(false);
  const [imageError, setImageError] = React.useState(false);
  const imgRef = React.useRef<HTMLImageElement>(null);

  React.useEffect(() => {
    if (imgRef.current?.complete && imgRef.current?.naturalWidth > 0) {
      setImageLoaded(true);
    }
  }, [item.file_url]);

  const isGenerating = generatingId === item.id;
  const isVideo = item.mime_type?.startsWith('video/') || item.file_url.match(/\.(mp4|mov|webm)$/i);
  const isBulkDone = bulkCompletedIds.includes(item.id);
  const isBulkFailed = bulkFailedIds.includes(item.id);
  const isBulkPending = bulkGenerating && !isBulkDone && !isBulkFailed && generatingId !== item.id;

  return (
    <div
      onClick={() => {
        if (mode === 'library' && !hasSelection) {
          setPreviewItem(item);
        } else {
          onToggle();
        }
      }}
      className={`group relative aspect-square rounded-2xl overflow-hidden border-2 bg-gray-50 dark:bg-gray-800/50 cursor-pointer flex flex-col justify-end transition-all duration-200 ${
        isSelected
          ? 'border-blue-600 shadow-md ring-2 ring-blue-500/20'
          : isLastActive
          ? 'border-amber-500 dark:border-amber-400 ring-2 ring-amber-500/40 shadow-lg shadow-amber-500/20'
          : 'border-gray-100 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
      }`}
    >
      {/* Checkbox Selector */}
      {showCheckbox && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggle();
          }}
          aria-label={isSelected ? 'Deselect media' : 'Select media'}
          aria-checked={isSelected}
          role="checkbox"
          title={isSelected ? 'Deselect image' : 'Select image'}
          className={`absolute top-2.5 left-2.5 z-30 p-1 -m-1 rounded-xl cursor-pointer focus:outline-none group/selector select-none transition-all duration-150 ${
            mode === 'selector' && !isSelected ? 'opacity-85 hover:opacity-100' : 'opacity-100'
          }`}
        >
          <div
            className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all duration-150 shadow-md ${
              isSelected
                ? 'bg-blue-600 border-2 border-white text-white scale-105 shadow-blue-500/40 ring-2 ring-blue-500/30'
                : 'bg-black/55 hover:bg-black/80 backdrop-blur-md border-2 border-white/90 hover:border-white text-transparent hover:scale-110 shadow-black/40'
            }`}
          >
            {isSelected ? (
              <Check className="w-3.5 h-3.5 text-white stroke-[3]" />
            ) : (
              <div className="w-2 h-2 rounded-xs opacity-0 group-hover/selector:opacity-40 bg-white transition-opacity" />
            )}
          </div>
        </button>
      )}

      {/* Selector Mode Center Highlight (when selected in picker) */}
      {showCheckbox && mode === 'selector' && isSelected && (
        <div className="absolute inset-0 bg-blue-600/10 flex items-center justify-center z-10 pointer-events-none">
          <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center shadow-lg ring-2 ring-white">
            <Check className="h-4 w-4 text-white stroke-[3]" />
          </div>
        </div>
      )}

      {/* Selected Tint */}
      {isSelected && (
        <div className="absolute inset-0 bg-blue-600/15 pointer-events-none z-10" />
      )}

      {/* Media */}
      {isVideo ? (
        <>
          <video
            src={item.file_url}
            className="absolute inset-0 w-full h-full object-cover z-0"
            muted
            playsInline
            loop
            onMouseOver={e => { try { e.currentTarget.play(); } catch { } }}
            onMouseOut={e => { try { e.currentTarget.pause(); e.currentTarget.currentTime = 0; } catch { } }}
          />
          <div className="absolute bottom-3 left-3 z-10 bg-black/60 px-1.5 py-0.5 rounded text-white text-[8px] font-bold tracking-wider">VIDEO</div>
          <div className="absolute inset-0 flex items-center justify-center bg-black/10">
            <div className="p-1 rounded-full bg-black/50 text-white"><Play className="h-4 w-4 fill-white" /></div>
          </div>
        </>
      ) : (
        <>
          {!imageLoaded && !imageError && (
            <div className="absolute inset-0 bg-gray-100 dark:bg-gray-800/60 animate-pulse pointer-events-none z-[1] transition-opacity duration-300" />
          )}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            ref={imgRef}
            src={item.file_url}
            alt={item.alt_text || item.title || item.original_filename || 'Media'}
            loading={index !== undefined && index < 20 ? 'eager' : 'lazy'}
            fetchPriority={index !== undefined && index < 6 ? 'high' : 'auto'}
            decoding="async"
            onLoad={() => setImageLoaded(true)}
            onError={() => {
              setImageError(true);
              setImageLoaded(true);
            }}
            className="absolute inset-0 w-full h-full object-cover z-0"
          />
          {imageError && (
            <div className="absolute inset-0 bg-gray-100 dark:bg-gray-850 flex flex-col items-center justify-center p-2 text-center z-[1] text-gray-400">
              <span className="text-[10px] font-mono line-clamp-2 px-1">{item.original_filename || 'Image unavailable'}</span>
            </div>
          )}
        </>
      )}

      {/* Tagged / Pending Status Badge */}
      {showBadge && mode === 'library' && !bulkGenerating && (
        <div className="absolute top-2.5 right-2.5 z-10 pointer-events-none">
          {item.ai_generated ? (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[9px] font-bold bg-black/70 text-emerald-400 border border-emerald-500/30 shadow-xs">
              <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
              Tagged
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[9px] font-bold bg-black/70 text-amber-300 border border-amber-500/30 shadow-xs">
              <Clock className="w-2.5 h-2.5 text-amber-400" />
              Pending
            </span>
          )}
        </div>
      )}

      {/* Last Active Track Sign (Viewed / Edited) */}
      {isLastActive && (
        <div className={`absolute ${isVideo ? 'bottom-8' : 'bottom-2.5'} left-2.5 z-10 pointer-events-none transition-all`}>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-extrabold bg-amber-500 text-gray-950 shadow-md ring-1 ring-amber-300/80 tracking-tight">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-200 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-amber-950"></span>
            </span>
            <span>{lastActiveType === 'edited' ? 'Last Edited' : 'Last Viewed'}</span>
          </span>
        </div>
      )}

      {/* Bulk Progress Overlay */}
      {bulkGenerating && (
        <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
          {isBulkDone && (
            <div className="h-10 w-10 rounded-full bg-emerald-500 flex items-center justify-center shadow-lg ring-2 ring-emerald-300">
              <Check className="h-6 w-6 text-white" />
            </div>
          )}
          {isBulkFailed && (
            <div className="h-10 w-10 rounded-full bg-red-500 flex items-center justify-center shadow-lg ring-2 ring-red-300">
              <X className="h-6 w-6 text-white" />
            </div>
          )}
          {!isBulkDone && !isBulkFailed && isGenerating && (
            <div className="h-10 w-10 rounded-full bg-amber-500 flex items-center justify-center shadow-lg ring-2 ring-amber-300">
              <Loader2 className="h-6 w-6 text-white animate-spin" />
            </div>
          )}
          {isBulkPending && (
            <div className="absolute inset-0 bg-black/30 rounded-2xl" />
          )}
        </div>
      )}

      {/* Hover Actions */}
      {showActions && (
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-3 z-20 pointer-events-none">
          <div className="flex justify-end gap-1.5 pointer-events-auto">
            <button type="button" onClick={e => { e.stopPropagation(); setPreviewItem(item); }} className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer min-h-[32px]" title="Preview & Edit Image">
              <Eye className="w-3.5 h-3.5" />
            </button>
            <button type="button" onClick={e => { e.stopPropagation(); handleCopyUrl(item.file_url); }} className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer min-h-[32px]" title="Copy URL">
              <Copy className="w-3.5 h-3.5" />
            </button>
            {mode === 'library' && (
              <>
                <button type="button" onClick={e => { e.stopPropagation(); setEditingItem(item); }} className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer min-h-[32px]" title="Edit metadata">
                  <Edit className="w-3.5 h-3.5" />
                </button>
                <button type="button" onClick={e => { e.stopPropagation(); handleDelete(item.id, item.file_url); }} className="p-1.5 rounded-lg bg-white/10 hover:bg-red-500/80 text-white transition-all cursor-pointer min-h-[32px]" title="Delete">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
          <div className="space-y-1.5 pointer-events-auto">
            <div className="text-[10px] text-white font-mono line-clamp-1 w-full bg-black/40 p-1 rounded flex justify-between">
              <span className="truncate mr-1">Alt: {item.alt_text || 'None'}</span>
              <span className="flex-shrink-0 text-gray-300">{formatBytes(item.file_size)}</span>
            </div>
            {mode === 'library' && !isVideo && (
              <button type="button" onClick={e => { e.stopPropagation(); handleSingleGenerate(item); }} disabled={isGenerating}
                className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-white/95 hover:bg-white text-gray-950 font-bold text-[10px] transition-all cursor-pointer shadow-xs disabled:bg-gray-700 disabled:text-gray-400">
                {isGenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin text-gray-500" /> : <Sparkles className="w-3.5 h-3.5 text-amber-500" />}
                <span>Auto-generate Tags</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
