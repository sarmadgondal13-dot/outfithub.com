'use client';

import React, { useState } from 'react';
import { toast } from 'sonner';
import { X, Sparkles, Loader2 } from '@/components/common/Icons';
import { Modal } from '@/components/common/Modal';
import type { MediaItem } from './hooks/useMediaManagerData';

interface EditMetadataModalProps {
  editingItem: MediaItem;
  setEditingItem: React.Dispatch<React.SetStateAction<MediaItem | null>>;
  onSave: (e: React.FormEvent) => Promise<void>;
}

type GenTarget = 'alt' | 'title' | 'both';

const ALT_MAX = 125;

/** Strip markdown fences and parse the vision model's JSON reply. */
function parseVisionJson(raw: string): { alt_text?: string; title?: string } {
  let clean = (raw || '').trim();
  if (clean.includes('```json')) clean = clean.split('```json')[1].split('```')[0].trim();
  else if (clean.includes('```')) clean = clean.split('```')[1].split('```')[0].trim();
  try {
    return JSON.parse(clean);
  } catch {
    return {};
  }
}

export default function EditMetadataModal({
  editingItem,
  setEditingItem,
  onSave,
}: EditMetadataModalProps) {
  const [generating, setGenerating] = useState<GenTarget | null>(null);

  const isImage = !editingItem.mime_type || editingItem.mime_type.startsWith('image/');
  const altLength = (editingItem.alt_text || '').length;

  const buildPrompt = () => {
    const ctx = editingItem.original_filename ? `\nImage filename for context: ${editingItem.original_filename}` : '';
    return `Analyze this product image and return ONLY valid JSON (no markdown, no extra text):
{"alt_text":"...","title":"..."}
Rules:
- alt_text: descriptive, natural, 80-125 characters. Do NOT use "image of"/"picture of"/"photo of" filler and no keyword stuffing. Include the product type, colour, print/embroidery, fabric and set contents (e.g. 3-piece suit) where visible.
- title: short and clean, 40-60 characters, e.g. "Red Printed Lawn Suit with Dupatta".${ctx}`;
  };

  const handleGenerate = async (target: GenTarget) => {
    if (generating) return; // double-click / concurrency guard
    if (!editingItem.file_url) {
      toast.error('No image URL available for this media item.');
      return;
    }
    setGenerating(target);
    try {
      const res = await fetch('/api/ai/vision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: editingItem.file_url, prompt: buildPrompt() }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Generation failed (${res.status})`);
      }
      const data = await res.json();
      const meta = parseVisionJson(typeof data.result === 'string' ? data.result : JSON.stringify(data.result));
      const nextAlt = (meta.alt_text || '').trim();
      const nextTitle = (meta.title || '').trim();

      if (!nextAlt && !nextTitle) throw new Error('AI returned no usable text. Try again.');

      setEditingItem((prev) => {
        if (!prev) return null;
        const updated = { ...prev };
        if ((target === 'alt' || target === 'both') && nextAlt) updated.alt_text = nextAlt;
        if ((target === 'title' || target === 'both') && nextTitle) updated.title = nextTitle;
        return updated;
      });
      toast.success(target === 'both' ? 'Alt text & title generated' : `${target === 'alt' ? 'Alt text' : 'Title'} generated`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Generation failed';
      toast.error(msg);
    } finally {
      setGenerating(null);
    }
  };

  return (
    <Modal open onClose={() => setEditingItem(null)} showClose={false} size="sm" variant="sheet" className="max-h-[92dvh] sm:max-h-[90vh] flex flex-col">
      <div className="flex justify-between items-center p-4 border-b border-gray-100 dark:border-gray-800">
          <h3 className="font-bold text-gray-900 dark:text-white">Edit Image Metadata</h3>
          <button
            type="button"
            onClick={() => setEditingItem(null)}
            aria-label="Close"
            className="p-1 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={onSave} className="p-6 space-y-4 flex-1 overflow-y-auto overscroll-contain">
          {isImage && (
            <button
              type="button"
              onClick={() => handleGenerate('both')}
              disabled={!!generating}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gray-950 hover:bg-black dark:bg-white dark:text-gray-950 dark:hover:bg-gray-100 disabled:opacity-60 disabled:cursor-not-allowed transition-all cursor-pointer shadow-xs min-h-[44px] active:scale-[0.99]"
            >
              {generating === 'both' ? (
                <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
              ) : (
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              )}
              <span>{generating === 'both' ? 'Analyzing image...' : 'Auto-fill Alt Text & Title'}</span>
            </button>
          )}

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300">Alt Text Tag</label>
              {isImage && (
                <button
                  type="button"
                  onClick={() => handleGenerate('alt')}
                  disabled={!!generating}
                  className="flex items-center gap-1.5 text-[11px] font-semibold text-gray-700 hover:text-black dark:text-gray-300 dark:hover:text-white bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 px-2.5 py-1 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer min-h-[36px]"
                >
                  {generating === 'alt' ? <Loader2 className="w-3 h-3 animate-spin text-gray-500" /> : <Sparkles className="w-3 h-3 text-amber-500" />}
                  <span>Auto-fill</span>
                </button>
              )}
            </div>
            <input
              type="text"
              value={editingItem.alt_text || ''}
              onChange={(e) =>
                setEditingItem((prev) => (prev ? { ...prev, alt_text: e.target.value } : null))
              }
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1a1a30] text-gray-900 dark:text-white text-base sm:text-xs font-medium focus:border-gray-900 dark:focus:border-gray-400 focus:outline-hidden focus:ring-1 focus:ring-gray-900 dark:focus:ring-gray-400 min-h-[44px] sm:min-h-[42px] transition-colors"
            />
            <div className={`text-[10px] font-medium text-right ${altLength > ALT_MAX ? 'text-amber-600 font-semibold' : 'text-gray-400'}`}>
              {altLength}/{ALT_MAX}
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300">Title Tag</label>
              {isImage && (
                <button
                  type="button"
                  onClick={() => handleGenerate('title')}
                  disabled={!!generating}
                  className="flex items-center gap-1.5 text-[11px] font-semibold text-gray-700 hover:text-black dark:text-gray-300 dark:hover:text-white bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 px-2.5 py-1 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer min-h-[36px]"
                >
                  {generating === 'title' ? <Loader2 className="w-3 h-3 animate-spin text-gray-500" /> : <Sparkles className="w-3 h-3 text-amber-500" />}
                  <span>Auto-fill</span>
                </button>
              )}
            </div>
            <input
              type="text"
              value={editingItem.title || ''}
              onChange={(e) =>
                setEditingItem((prev) => (prev ? { ...prev, title: e.target.value } : null))
              }
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1a1a30] text-gray-900 dark:text-white text-base sm:text-xs font-medium focus:border-gray-900 dark:focus:border-gray-400 focus:outline-hidden focus:ring-1 focus:ring-gray-900 dark:focus:ring-gray-400 min-h-[44px] sm:min-h-[42px] transition-colors"
            />
          </div>

          <div className="pt-4 flex justify-end gap-2 border-t border-gray-100 dark:border-gray-800 pb-[calc(1rem+env(safe-area-inset-bottom,0px))]">
            <button
              type="button"
              onClick={() => setEditingItem(null)}
              className="flex-1 sm:flex-initial px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 font-semibold text-xs cursor-pointer min-h-[44px] sm:min-h-[38px] transition-colors flex items-center justify-center"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 sm:flex-initial px-5 py-2 text-white rounded-xl font-bold text-xs bg-gray-950 hover:bg-black dark:bg-white dark:text-gray-950 dark:hover:bg-gray-100 transition-all flex items-center justify-center gap-2 cursor-pointer min-h-[44px] sm:min-h-[38px] shadow-xs active:scale-95"
            >
              Save Details
            </button>
          </div>
        </form>
    </Modal>
  );
}
