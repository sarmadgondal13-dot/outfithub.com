'use client';

import { useState, useEffect, useRef } from 'react';
import { Product } from '@/lib/types';
import { toast } from 'sonner';
import { createClient } from '@/lib/supabase/client';
import { rankProducts } from '@/lib/services/product-search/useInMemoryProductSearch';

interface ProductImageRow {
  id: string;
  url: string;
  sort_order?: number;
  is_primary?: boolean;
}

interface ProductVariantRow {
  id: string;
  color?: string | null;
  size?: string | null;
  stock?: number | null;
  price?: number | string | null;
  sku?: string | null;
  active?: boolean;
}

interface ProductRow {
  id: string;
  name: string;
  slug: string;
  price?: number | string | null;
  compare_price?: number | string | null;
  sku?: string | null;
  stock?: number | null;
  has_variants?: boolean;
  images?: ProductImageRow[];
  variants?: ProductVariantRow[];
  created_at?: string;
  updated_at?: string;
}

export function useOrderCreateProducts(isOpen: boolean) {
  const [dbProducts, setDbProducts] = useState<Product[]>([]);
  const [isLoadingProducts, setIsLoadingProducts] = useState(false);

  // Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Active selection states
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [chosenSize, setChosenSize] = useState('');
  const [chosenColor, setChosenColor] = useState('');
  const [chosenVariantId, setChosenVariantId] = useState('');
  const [chosenQuantity, setChosenQuantity] = useState('1');
  const [customUnitPrice, setCustomUnitPrice] = useState('');

  // Load products from DB on open
  useEffect(() => {
    if (!isOpen) return;

    const fetchProducts = async () => {
      setIsLoadingProducts(true);
      try {
        const supabase = createClient();
        const { data, error } = await supabase
          .from('products')
          .select(`
            id, name, slug, price, compare_price, sku, stock, has_variants,
            images:product_images(id, url, sort_order, is_primary),
            variants:product_variants(id, color, size, stock, price, sku, active)
          `)
          .eq('is_active', true);

        if (error) throw error;

        if (data) {
          const mapped: Product[] = (data as ProductRow[]).map((p) => ({
            id: p.id,
            name: p.name,
            slug: p.slug,
            price: p.price ? parseFloat(p.price.toString()) : 0,
            compare_price: p.compare_price ? parseFloat(p.compare_price.toString()) : undefined,
            sku: p.sku || undefined,
            stock: p.stock || 0,
            has_variants: p.has_variants || false,
            is_service: false,
            is_featured: false,
            is_active: true,
            enable_swatches: false,
            show_swatches_on_archive: false,
            tags: [],
            images: (p.images || []).map((img) => ({
              id: img.id,
              product_id: p.id,
              url: img.url,
              sort_order: img.sort_order || 0,
              is_primary: img.is_primary || false,
              created_at: new Date().toISOString()
            })),
            variants: (p.variants || []).filter((v) => v.active).map((v) => ({
              id: v.id,
              product_id: p.id,
              color: v.color || undefined,
              size: v.size || undefined,
              stock: v.stock || 0,
              price: v.price ? parseFloat(v.price.toString()) : undefined,
              sku: v.sku || undefined,
              active: v.active || false,
              sort_order: 0
            })),
            modifiers: [],
            created_at: p.created_at || new Date().toISOString(),
            updated_at: p.updated_at || new Date().toISOString()
          }));
          setDbProducts(mapped);
        }
      } catch (err) {
        console.error(err);
        toast.error('Failed to load products list');
      } finally {
        setIsLoadingProducts(false);
      }
    };

    fetchProducts();
  }, [isOpen]);

  // Click outside search dropdown close handler
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter products based on search (shared ranking engine — SSOT)
  const filteredProducts = searchQuery.trim()
    ? rankProducts(dbProducts, searchQuery)
    : dbProducts;

  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product);
    setSearchQuery(product.name);
    setIsDropdownOpen(false);
    setChosenSize('');
    setChosenColor('');
    setChosenVariantId('');
    setChosenQuantity('1');
    setCustomUnitPrice(product.price.toString());
  };

  return {
    dbProducts,
    isLoadingProducts,
    searchQuery,
    setSearchQuery,
    isDropdownOpen,
    setIsDropdownOpen,
    dropdownRef,
    selectedProduct,
    setSelectedProduct,
    chosenSize,
    setChosenSize,
    chosenColor,
    setChosenColor,
    chosenVariantId,
    setChosenVariantId,
    chosenQuantity,
    setChosenQuantity,
    customUnitPrice,
    setCustomUnitPrice,
    filteredProducts,
    handleProductSelect,
  };
}
