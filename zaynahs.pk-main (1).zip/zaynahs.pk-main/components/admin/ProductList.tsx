'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { Product, StoreSettings } from '@/lib/types';
import { 
  deleteProductAction as deleteProduct, 
  updateProductFieldsAction as updateProductFields,
  bulkDeleteProductsAction,
  bulkUpdateProductFieldsAction
} from '@/lib/services/products/actions';
import { triggerMetaSync } from '@/lib/services/metaSyncAction';
import { toast } from 'sonner';
import { useConfirm } from '@/components/admin/shared/AdminConfirmProvider';
import ImportExportModal from '@/components/admin/ImportExportModal';
import PaginationFooter from './PaginationFooter';
import ImagePreviewModal from '@/components/admin/ImagePreviewModal';
import { saveProductNavContext, getAdminNavContext } from '@/lib/hooks/useProductNav';
import { applySort } from '@/lib/sorting/sortOptions';
import { rankProducts } from '@/lib/services/product-search/useInMemoryProductSearch';
import { getProductOptionSummary } from '@/lib/utils/formatVariant';
import { 
  ProductListToolbar, 
  ProductListBulkActions, 
  ProductListTable 
} from './product-list';
import type { ProductTab } from './product-list/ProductListToolbar';

interface ProductListProps {
  initialProducts: Product[];
  settings: StoreSettings;
}

export default function ProductList({ initialProducts, settings }: ProductListProps) {
  const router = useRouter();
  const { confirm } = useConfirm();
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [searchQuery, setSearchQuery] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = getAdminNavContext('/admin/products');
      if (typeof saved?.searchQuery === 'string') return saved.searchQuery;
    }
    return '';
  });
  const [syncingAll, setSyncingAll] = useState(false);
  const [syncingFailed, setSyncingFailed] = useState(false);
  const [syncingProductId, setSyncingProductId] = useState<string | null>(null);
  const [isImportExportOpen, setIsImportExportOpen] = useState(false);
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const saved = getAdminNavContext('/admin/products');
      if (saved?.sortBy) return saved.sortBy;
    }
    return 'newest';
  });
  const [selectedCategory, setSelectedCategory] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const saved = getAdminNavContext('/admin/products');
      if (saved?.selectedCategory) return saved.selectedCategory;
    }
    return 'all';
  });
  const [pageSize, setPageSize] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = getAdminNavContext('/admin/products');
      if (saved?.pageSize && saved.pageSize > 0) return saved.pageSize;
    }
    return 20;
  });
  const [currentPage, setCurrentPage] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = getAdminNavContext('/admin/products');
      if (saved?.page && saved.page > 0) return saved.page;
    }
    return 1;
  });
  const [activeTab, setActiveTab] = useState<ProductTab>(() => {
    if (typeof window !== 'undefined') {
      const saved = getAdminNavContext('/admin/products');
      if (saved?.activeTab) return saved.activeTab as ProductTab;
    }
    return 'all';
  });
  const [previewImageUrl, setPreviewImageUrl] = useState<string | null>(null);

  /** Save nav context then navigate to edit page */
  const handleEditProduct = (productId: string, allFiltered: Product[]) => {
    const mainContent = document.getElementById('admin-main-content');
    const scrollPos = mainContent ? mainContent.scrollTop : (typeof window !== 'undefined' ? window.scrollY : 0);
    saveProductNavContext({
      ids: allFiltered.map(p => p.id),
      source: 'Products',
      sourceUrl: '/admin/products',
      lastOpenedId: productId,
      page: currentPage,
      pageSize,
      searchQuery,
      selectedCategory,
      sortBy,
      activeTab,
      scrollPosition: scrollPos,
    });
    router.push(`/admin/products/${productId}`);
  };

  /** Restore scroll & highlight on return to Products list */
  useEffect(() => {
    const saved = getAdminNavContext('/admin/products');
    if (!saved?.lastOpenedId) return;

    const targetId = saved.lastOpenedId;
    const scrollPos = saved.scrollPosition;

    const timer = setTimeout(() => {
      const row = document.getElementById(`product-row-${targetId}`)
               || document.getElementById(`product-card-${targetId}`);
      if (row) {
        row.scrollIntoView({ block: 'center', behavior: 'smooth' });
        row.classList.remove('scroll-restore-highlight');
        void row.offsetWidth;
        row.classList.add('scroll-restore-highlight');
        setTimeout(() => row.classList.remove('scroll-restore-highlight'), 2500);
      } else if (typeof scrollPos === 'number' && scrollPos > 0) {
        const mainContent = document.getElementById('admin-main-content');
        if (mainContent) {
          mainContent.scrollTo({ top: scrollPos, behavior: 'smooth' });
        }
      }
    }, 120);

    return () => clearTimeout(timer);
  }, []);

  const categoriesMap = new Map<string, string>();
  products.forEach(p => {
    if (p.product_categories) {
      p.product_categories.forEach(pc => {
        if (pc.category && pc.category_id) categoriesMap.set(pc.category_id, pc.category.name);
      });
    }
    if (p.category && p.category_id) {
      categoriesMap.set(p.category_id, p.category.name);
    }
  });
  const availableCategories = Array.from(categoriesMap.entries())
    .map(([id, name]) => ({ id, name }))
    .sort((a, b) => a.name.localeCompare(b.name));

  const handleBulkFeatured = async (featuredValue: boolean) => {
    if (selectedProductIds.length === 0) return;
    const toastId = toast.loading(`Updating ${selectedProductIds.length} products...`);
    try {
      await bulkUpdateProductFieldsAction(selectedProductIds, { is_featured: featuredValue });
      setProducts(prev => prev.map(p => selectedProductIds.includes(p.id) ? { ...p, is_featured: featuredValue } : p));
      toast.success(`Successfully updated ${selectedProductIds.length} products`, { id: toastId });
      setSelectedProductIds([]);
    } catch {
      toast.error('Failed to update products featured status', { id: toastId });
    }
  };

  const handleBulkDelete = async () => {
    if (selectedProductIds.length === 0) return;
    const confirmed = await confirm({
      title: 'Bulk Move to Trash',
      message: `Are you sure you want to move ${selectedProductIds.length} products to Trash?`,
      variant: 'danger',
      confirmText: 'Move to Trash'
    });
    if (!confirmed) return;
    const toastId = toast.loading(`Moving ${selectedProductIds.length} products to Trash...`);
    try {
      await bulkDeleteProductsAction(selectedProductIds);
      setProducts(prev => prev.filter(p => !selectedProductIds.includes(p.id)));
      toast.success(`Moved ${selectedProductIds.length} products to Trash`, { id: toastId });
      setSelectedProductIds([]);
    } catch {
      toast.error('Failed to move products to Trash', { id: toastId });
    }
  };

  const handleBulkMetaSync = async () => {
    if (selectedProductIds.length === 0) return;
    const toastId = toast.loading(`Syncing ${selectedProductIds.length} products to Meta catalog...`);
    try {
      const results = await Promise.all(selectedProductIds.map(async (id) => {
        try {
          const res = await triggerMetaSync(id);
          return { id, success: res.success, error: res.error };
        } catch (e: unknown) {
          return { id, success: false, error: e instanceof Error ? e.message : 'Unknown error' };
        }
      }));
      
      const failed = results.filter(r => !r.success);
      
      setProducts(prev => prev.map(p => {
        const result = results.find(r => r.id === p.id);
        if (result) {
          return {
            ...p,
            meta_sync_status: result.success ? 'synced' as const : 'error' as const,
            meta_sync_error: result.success ? null : result.error
          };
        }
        return p;
      }));

      if (failed.length === 0) {
        toast.success('All selected products synced successfully', { id: toastId });
      } else {
        toast.warning(`Synced with ${failed.length} failure(s)`, { id: toastId });
      }
      setSelectedProductIds([]);
    } catch {
      toast.error('Failed to execute bulk sync', { id: toastId });
    }
  };

  const handleDelete = async (id: string) => {
    const confirmed = await confirm({
      title: 'Move to Trash',
      message: 'Are you sure you want to move this product to Trash?',
      variant: 'danger',
      confirmText: 'Move to Trash'
    });
    if (!confirmed) return;
    try {
      await deleteProduct(id);
      setProducts(prev => prev.filter(p => p.id !== id));
      toast.success('Product moved to Trash successfully');
    } catch {
      toast.error('Failed to move product to Trash');
    }
  };

  const handleToggleFeatured = async (product: Product) => {
    try {
      const nextFeatured = !product.is_featured;
      await updateProductFields(product.id, { is_featured: nextFeatured });
      setProducts(prev => prev.map(p => p.id === product.id ? { ...p, is_featured: nextFeatured } : p));
      toast.success(`Product ${nextFeatured ? 'marked as featured' : 'removed from featured'} successfully`);
    } catch (err) {
      console.error('[ProductList] handleToggleFeatured failed:', err);
      toast.error('Failed to update product featured status');
    }
  };

  const handleToggleActive = async (product: Product) => {
    try {
      const nextActive = !product.is_active;
      await updateProductFields(product.id, { is_active: nextActive });
      setProducts(prev => prev.map(p => p.id === product.id ? { ...p, is_active: nextActive } : p));
      toast.success(`Product ${nextActive ? 'visible on store' : 'hidden from store'} successfully`);
    } catch (err) {
      console.error('[ProductList] handleToggleActive failed:', err);
      toast.error('Failed to update product visibility');
    }
  };

  const handleSyncAll = async () => {
    setSyncingAll(true);
    try {
      const res = await fetch('/api/meta-sync/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'all' })
      });
      const data = await res.json();
      if (data.success) {
        toast.success(`Successfully synced ${data.totalSynced} products to Meta catalog`);
        window.location.reload();
      } else {
        toast.error(`Sync failed: ${data.errors?.join(', ') || 'Unknown error'}`);
      }
    } catch {
      toast.error('Bulk sync request failed');
    } finally {
      setSyncingAll(false);
    }
  };

  const handleSyncFailed = async () => {
    setSyncingFailed(true);
    try {
      const res = await fetch('/api/meta-sync/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'failed' })
      });
      const data = await res.json();
      if (data.success) {
        toast.success(`Successfully synced ${data.totalSynced} failed/pending products to Meta`);
        window.location.reload();
      } else {
        toast.error(`Sync failed: ${data.errors?.join(', ') || 'Unknown error'}`);
      }
    } catch {
      toast.error('Retry sync request failed');
    } finally {
      setSyncingFailed(false);
    }
  };

  const handleSingleSync = async (productId: string) => {
    setSyncingProductId(productId);
    try {
      const res = await triggerMetaSync(productId);
      if (res.success) {
        toast.success('Product synced to Meta catalog successfully');
        setProducts(prev => prev.map(p => p.id === productId ? { 
          ...p, 
          meta_sync_status: 'synced', 
          meta_sync_error: null
        } : p));
      } else {
        toast.error(`Failed to sync: ${res.error}`);
        setProducts(prev => prev.map(p => p.id === productId ? { 
          ...p, 
          meta_sync_status: 'error', 
          meta_sync_error: res.error 
        } : p));
      }
    } catch {
      toast.error('Sync failed');
    } finally {
      setSyncingProductId(null);
    }
  };

  // Compute counts for the status tabs
  const tabCounts = useMemo(() => {
    let visible = 0;
    let featured = 0;
    let lowStock = 0;
    let hidden = 0;

    for (const p of products) {
      if (p.is_active) visible++;
      else hidden++;
      if (p.is_featured) featured++;
      const opt = getProductOptionSummary(p);
      if (opt.totalStock < 5) lowStock++;
    }

    return {
      all: products.length,
      visible,
      featured,
      low_stock: lowStock,
      hidden,
    };
  }, [products]);

  // Tab filter first
  const tabScoped = useMemo(() => {
    if (activeTab === 'visible') return products.filter(p => p.is_active);
    if (activeTab === 'featured') return products.filter(p => p.is_featured);
    if (activeTab === 'low_stock') {
      return products.filter(p => {
        const opt = getProductOptionSummary(p);
        return opt.totalStock < 5;
      });
    }
    if (activeTab === 'hidden') return products.filter(p => !p.is_active);
    return products;
  }, [products, activeTab]);

  // Category filter next (keeps admin scoping), then the shared ranking engine
  // handles the text query (title → sku → variant → short → tags → category → long).
  const categoryScoped = tabScoped.filter(p => {
    if (selectedCategory === 'all') return true;
    if (p.product_categories && p.product_categories.length > 0) {
      return p.product_categories.some(pc => pc.category_id === selectedCategory);
    }
    return p.category_id === selectedCategory;
  });

  const baseFilteredProducts = searchQuery.trim()
    ? rankProducts(categoryScoped, searchQuery)
    : categoryScoped;

  const filteredProducts = (searchQuery.trim() || sortBy === 'manual')
    ? baseFilteredProducts
    : applySort(baseFilteredProducts, sortBy);

  const totalFiltered = filteredProducts.length;
  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  return (
    <div className="space-y-6">
      {/* Search & Actions header */}
      <ProductListToolbar
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        sortBy={sortBy}
        setSortBy={setSortBy}
        availableCategories={availableCategories}
        settings={settings}
        syncingAll={syncingAll}
        syncingFailed={syncingFailed}
        onSyncAll={handleSyncAll}
        onSyncFailed={handleSyncFailed}
        onOpenImportExport={() => setIsImportExportOpen(true)}
        setCurrentPage={setCurrentPage}
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          setSelectedProductIds([]);
        }}
        tabCounts={tabCounts}
      />

      {/* Bulk action toolbar */}
      <ProductListBulkActions
        selectedProductIds={selectedProductIds}
        setSelectedProductIds={setSelectedProductIds}
        settings={settings}
        onBulkFeatured={handleBulkFeatured}
        onBulkMetaSync={handleBulkMetaSync}
        onBulkDelete={handleBulkDelete}
      />

      {/* Table listing */}
      <ProductListTable
        filteredProducts={filteredProducts}
        paginatedProducts={paginatedProducts}
        selectedProductIds={selectedProductIds}
        setSelectedProductIds={setSelectedProductIds}
        settings={settings}
        syncingProductId={syncingProductId}
        setPreviewImageUrl={setPreviewImageUrl}
        handleToggleActive={handleToggleActive}
        handleToggleFeatured={handleToggleFeatured}
        handleSingleSync={handleSingleSync}
        handleEditProduct={handleEditProduct}
        handleDelete={handleDelete}
      />

      <PaginationFooter
        totalItems={totalFiltered}
        pageSize={pageSize}
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        onPageSizeChange={setPageSize}
      />

      <ImportExportModal
        isOpen={isImportExportOpen}
        onClose={() => setIsImportExportOpen(false)}
        products={products}
        onImportComplete={() => {
          window.location.reload();
        }}
      />
      
      <ImagePreviewModal 
        url={previewImageUrl} 
        onClose={() => setPreviewImageUrl(null)} 
      />
    </div>
  );
}
