import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getAISettings } from '@/lib/ai';
import { routeVision, extractKeys } from '@/lib/ai/router';

export const runtime = 'nodejs';

/**
 * POST /api/ai/vision
 * Accept: { image: string (URL), prompt?: string, provider?: string }
 * Returns: { result, provider, model }
 */
export async function POST(req: NextRequest) {
  const _denied = await requireAdmin(req);
  if (_denied) return _denied;
  try {
    const { image, prompt, provider: forcedProvider } = await req.json();

    if (!image) {
      return NextResponse.json({ error: 'Image URL is required' }, { status: 400 });
    }

    const settings = await getAISettings();
    const keys = extractKeys(settings);

    const systemPrompt = `You are an expert Image SEO optimizer. Analyze the provided image and generate relevant SEO tags. Return ONLY a valid JSON object matching the requested schema. Do not include markdown code block wrappers or extra text.`;

    const userPrompt = prompt || `Analyze this image and return ONLY this JSON schema:
{
  "alt_text": "Highly descriptive, SEO-friendly ALT text focusing on clothing attributes, material, and color.",
  "seo_filename": "hyphen-separated-lowercase-filename.webp",
  "title": "Clean, descriptive title for the image.",
  "description": "A 100-150 words detailed description of what is visible in the image.",
  "caption": "A short, engaging caption for the image."
}`;

    // If a specific provider is forced, use only that one
    if (forcedProvider && keys.vision[forcedProvider]) {
      const result = await routeVision(userPrompt, systemPrompt, image, {
        [forcedProvider]: keys.vision[forcedProvider],
      }, settings.vision_model);
      return NextResponse.json(result);
    }

    // Otherwise use full fallback chain
    const result = await routeVision(userPrompt, systemPrompt, image, keys.vision, settings.vision_model);
    if (!result) {
      return NextResponse.json({ error: 'All vision providers failed' }, { status: 503 });
    }

    return NextResponse.json(result);
  } catch (err: unknown) {
    console.error('[Vision API]', err);
    const message = err instanceof Error ? err.message : 'Vision analysis failed';
    const status = typeof (err as { status?: unknown })?.status === 'number'
      ? (err as { status: number }).status
      : 500;
    return NextResponse.json(
      { error: message },
      { status },
    );
  }
}
