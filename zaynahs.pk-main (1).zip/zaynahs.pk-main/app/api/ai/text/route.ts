import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getAISettings } from '@/lib/ai';
import { routeText, extractKeys } from '@/lib/ai/router';

export const runtime = 'nodejs';

/**
 * POST /api/ai/text
 * Accept: { prompt: string, systemPrompt?: string, provider?: string }
 * Returns: { result, provider, model }
 */
export async function POST(req: NextRequest) {
  const _denied = await requireAdmin(req);
  if (_denied) return _denied;
  try {
    const { prompt, systemPrompt: customSystemPrompt, provider: forcedProvider } = await req.json();

    if (!prompt) {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    const settings = await getAISettings();
    const keys = extractKeys(settings);

    const systemPrompt = customSystemPrompt || `You are an expert e-commerce SEO content writer for kids clothing. Return ONLY valid JSON.`;

    if (forcedProvider && keys.text[forcedProvider]) {
      const result = await routeText(prompt, systemPrompt, {
        [forcedProvider]: keys.text[forcedProvider],
      }, settings.content_model);
      return NextResponse.json(result);
    }

    const result = await routeText(prompt, systemPrompt, keys.text, settings.content_model);
    if (!result) {
      return NextResponse.json({ error: 'All text providers failed' }, { status: 503 });
    }

    return NextResponse.json(result);
  } catch (err: unknown) {
    console.error('[Text API]', err);
    const message = err instanceof Error ? err.message : 'Text generation failed';
    const status = typeof (err as { status?: unknown })?.status === 'number'
      ? (err as { status: number }).status
      : 500;
    return NextResponse.json(
      { error: message },
      { status },
    );
  }
}
