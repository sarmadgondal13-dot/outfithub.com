import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getAISettings } from '@/lib/ai';
import { routeVision, extractKeys } from '@/lib/ai/router';
import { supabaseAdmin } from '@/lib/supabase/admin';

export const runtime = 'nodejs';

const ANALYSIS_PROMPT = `Analyze this kids clothing product image. Return ONLY this JSON schema (no markdown, no code blocks):
{
  "title": "Product title (max 60 chars, SEO-optimized)",
  "description": "Product description (100-150 words, for SEO meta description and product page)",
  "category": "Best matching category name (e.g., T-Shirts, Dresses, Shoes, Accessories)",
  "colors": ["list", "of", "detected", "colors"],
  "sizes": ["list", "of", "likely", "sizes"],
  "seo_keywords": ["5-10", "relevant", "SEO", "keywords"],
  "style": "e.g., Casual, Formal, Party Wear, Sportswear",
  "material": "Detected or likely fabric/material",
  "gender": "Boys, Girls, Unisex"
}`;

/**
 * POST /api/ai/product-analyzer
 * Accept: { imageUrl: string, productType?: string }
 * Returns: { result: {...analysis}, provider, model }
 */
export async function POST(req: NextRequest) {
  const _denied = await requireAdmin(req);
  if (_denied) return _denied;
  try {
    const { imageUrl } = await req.json();

    if (!imageUrl) {
      return NextResponse.json({ error: 'imageUrl is required' }, { status: 400 });
    }

    const settings = await getAISettings();

    if (!settings.ai_enabled) {
      return NextResponse.json({ error: 'AI features are disabled' }, { status: 403 });
    }

    const keys = extractKeys(settings);
    const systemPrompt = `You are an expert kids clothing product analyzer. Extract detailed product information from images. Return ONLY valid JSON.`;

    const result = await routeVision(
      ANALYSIS_PROMPT,
      systemPrompt,
      imageUrl,
      keys.vision,
      settings.vision_model,
    );

    if (!result) {
      return NextResponse.json({ error: 'All vision providers failed' }, { status: 503 });
    }

    return NextResponse.json(result);
  } catch (err: unknown) {
    console.error('[Product Analyzer]', err);
    const message = err instanceof Error ? err.message : 'Product analysis failed';
    const status = typeof (err as { status?: unknown })?.status === 'number' ? (err as { status: number }).status : 500;
    return NextResponse.json(
      { error: message },
      { status },
    );
  }
}
