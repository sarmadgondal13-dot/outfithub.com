import { NextRequest, NextResponse } from 'next/server';
import { revalidatePath, revalidateTag } from 'next/cache';
import {
  revalidateProduct,
  revalidateAllProducts,
  purgeAllCloudflareZones,
  revalidateBanner,
  revalidateCategory,
  revalidateHomepage,
  revalidateSettings,
  revalidateVertical,
  revalidateAfterResponse,
} from '@/lib/revalidate';
import { getProductById } from '@/lib/services/products';
import { syncProductToMeta } from '@/lib/meta/syncProduct';

/**
 * POST endpoint for Supabase database update webhooks.
 * Authenticates using x-revalidate-secret header and triggers Next.js and Cloudflare cache revalidation.
 */
// The delayed follow-up edge purge runs via `after()` (waitUntil); give it room.
export const maxDuration = 30;

export async function POST(req: NextRequest) {
  try {
    // 1. Verify REVALIDATE_SECRET
    const secret = req.headers.get('x-revalidate-secret');
    if (!secret || secret !== process.env.REVALIDATE_SECRET) {
      console.warn('[Webhook Revalidate] Unauthorized request. Secret token mismatch.');
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // 2. Parse payload body
    const body = await req.json().catch(() => ({}));
    const { type, table, record, old_record } = body;

    console.log(`[Webhook Revalidate] Received table trigger. Table: ${table}, Type: ${type}`);

    // If deleting, fields are in old_record. Otherwise in record.
    // DB triggers may not include record data (body: {"type":"CHANGE","table":"..."})
    // Default to {} so table-level handlers (store_settings, banners, fallback) still work.
    const activeRecord = (type === 'DELETE' ? old_record : record) ?? {};

    if (!table) {
      return NextResponse.json({ error: 'No table found in payload' }, { status: 400 });
    }

    // If this is a manual deploy ping from Vercel (or a manual curl)
    if (type === 'deploy' || table === 'deploy') {
      console.log('[Webhook Revalidate] Received manual/Vercel deploy trigger. Purging everything.');
      await Promise.all([revalidateHomepage(), revalidateAllProducts()]);
      return NextResponse.json({ message: 'Deployment cache purge successful' });
    }

    // 3. Dispatch to specific revalidation handler
    const childTables = ['product_variants', 'product_images', 'product_modifiers', 'reviews'];

    if (table === 'products') {
      // 🛡️ LOOP GUARD: If the UPDATE only changed meta_sync fields, skip everything.
      // This prevents the infinite loop: meta_sync update → webhook → meta_sync update → ...
      const META_ONLY_COLUMNS = new Set(['meta_sync_status', 'meta_sync_error', 'meta_last_synced_at', 'updated_at']);
      if (type === 'UPDATE' && record && old_record) {
        const changedColumns = Object.keys(record).filter(
          (key) => record[key] !== old_record[key]
        );
        const isMetaOnly = changedColumns.length > 0 && changedColumns.every((col) => META_ONLY_COLUMNS.has(col));
        if (isMetaOnly) {
          console.log('[Webhook Revalidate] Skipping — only meta_sync fields changed, no real product update.');
          return NextResponse.json({ revalidated: false, reason: 'meta_sync_only' });
        }
      }

      const slug = activeRecord.slug;
      if (slug) {
        await revalidateProduct(slug);
      } else {
        console.warn('[Webhook Revalidate] Product update received but slug was missing — refreshing all product pages.');
        await revalidateAllProducts();
      }

      // Real-time sync to Meta Catalog
      try {
        if (type === 'DELETE') {
          await syncProductToMeta(activeRecord, 'DELETE');
        } else {
          const fullProduct = await getProductById(activeRecord.id);
          if (fullProduct) {
            await syncProductToMeta(fullProduct, 'UPDATE');
          }
        }
      } catch (metaErr) {
        console.error('[Webhook Revalidate] Meta Catalog Sync failed:', metaErr);
      }
    } else if (childTables.includes(table)) {
      const productId = activeRecord.product_id;
      if (productId) {
        const product = await getProductById(productId);
        if (product && product.slug) {
          await revalidateProduct(product.slug);
          console.log(`[Webhook Revalidate] Revalidated parent product ${product.slug} due to change in table ${table}`);

          // Real-time Meta sync when variants or images change
          try {
            await syncProductToMeta(product, 'UPDATE');
            console.log(`[Webhook Revalidate] Synced updated product ${product.id} to Meta Catalog.`);
          } catch (metaErr) {
            console.error('[Webhook Revalidate] Meta Catalog Sync for child table failed:', metaErr);
          }
        } else {
          console.warn(`[Webhook Revalidate] Parent product not found or slug missing for product ID: ${productId}`);
        }
      } else {
        console.warn(`[Webhook Revalidate] Table is ${table} but product_id was missing from activeRecord — refreshing all product pages.`);
        await revalidateAllProducts();
      }
    } else if (table === 'banners' || table === 'homepage_sections') {
      await revalidateBanner();
    } else if (table === 'product_categories') {
      // Per-category manual order (position) changed → refresh shop + category listings.
      await revalidateSettings();
    } else if (table === 'categories') {
      const slug = activeRecord.slug;
      if (slug) {
        await revalidateCategory(slug);
      } else {
        // No slug in payload (e.g. DB trigger without record) — full settings revalidation
        console.warn('[Webhook Revalidate] Category update: no slug, falling back to revalidateSettings.');
        await revalidateSettings();
      }
    } else if (table === 'store_settings') {
      await revalidateSettings();
    } else if (table === 'verticals') {
      const slug = activeRecord.slug;
      if (slug) {
        await revalidateVertical(slug);
      } else {
        console.warn('[Webhook Revalidate] Vertical update: no slug, falling back to revalidateSettings.');
        await revalidateSettings();
      }
    } else {
      console.log(`[Webhook Revalidate] Table ${table} has no specific handler. Revalidating settings completely.`);
      await revalidateSettings();
    }

    // RULE C10/D12: the first visit after invalidation can still receive Next's
    // stale-while-revalidate payload, which Cloudflare would then re-cache for
    // 30 days. Purge the edge a second time after the origin has regenerated so
    // the fresh HTML is what gets cached.
    await revalidateAfterResponse(async () => {
      await new Promise((resolve) => setTimeout(resolve, 3500));
      await purgeAllCloudflareZones();
    });

    return NextResponse.json({ revalidated: true, table, type });
  } catch (error: unknown) {
    console.error('[Webhook Revalidate] Revalidation endpoint internal error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal Server Error' },
      { status: 500 }
    );
  }
}

/**
 * GET requests are not allowed.
 */
export async function GET() {
  return new NextResponse('Method Not Allowed', { status: 405 });
}
