import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getSettings, updateSettings } from '@/lib/services/settings';

export const revalidate = 0; // Disable dynamic caching for this API route

export async function GET() {
  try {
    const settings = await getSettings();
    return NextResponse.json({
      theme_preset: settings.theme_preset || 'classic_white',
      theme_config: settings.theme_config || null,
    });
  } catch (error: unknown) {
    console.error('[API Theme GET] failed:', error);
    const message = error instanceof Error ? error.message : 'Internal server error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const _denied = await requireAdmin(request);
  if (_denied) return _denied;
  try {
    const body = await request.json();
    const { theme_preset, theme_config } = body;
    
    if (!theme_preset) {
      return NextResponse.json({ error: 'theme_preset is required' }, { status: 400 });
    }
    
    const updated = await updateSettings({
      theme_preset,
      theme_config,
    });
    
    return NextResponse.json({
      success: true,
      theme_preset: updated.theme_preset,
      theme_config: updated.theme_config,
    });
  } catch (error: unknown) {
    console.error('[API Theme POST] failed:', error);
    const message = error instanceof Error ? error.message : 'Internal server error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
