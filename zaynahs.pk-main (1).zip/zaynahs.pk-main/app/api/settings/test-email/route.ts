import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth/requireAdmin';
import { getSettings } from '@/lib/services/settings';
import { sendEmail } from '@/lib/email/sendEmail';

export async function POST(request: NextRequest) {
  const _denied = await requireAdmin(request);
  if (_denied) return _denied;
  try {
    const settings = await getSettings();
    const adminEmail = settings.admin_notification_email || settings.smtp_email;

    if (!adminEmail) {
      return NextResponse.json({ success: false, error: 'Admin notification email is not configured.' }, { status: 400 });
    }

    const brandName = settings.store_name || process.env.NEXT_PUBLIC_BRAND_NAME || 'Your Store';
    const result = await sendEmail({
      to: adminEmail,
      subject: `Test Email from ${brandName}`,
      html: `
        <div style="font-family: sans-serif; padding: 20px; color: #1a1a1a;">
          <h2 style="color: #1a1a2e;">SMTP Configuration Verified!</h2>
          <p>If you received this message, your SMTP settings for <strong>${brandName}</strong> are working correctly!</p>
          <p style="color: #6b7280; font-size: 13px; margin-top: 24px;">This is a test notification from the Admin Panel.</p>
        </div>
      `
    });

    if (!result.success) {
      return NextResponse.json({ success: false, error: result.error || 'Failed to dispatch test mail' });
    }

    return NextResponse.json({ success: true, message: `Test email dispatched successfully to ${adminEmail}` });
  } catch (error: unknown) {
    console.error('[API test-email] POST failed:', error);
    const message = error instanceof Error ? error.message : 'Internal server error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
