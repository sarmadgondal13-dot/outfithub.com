import { MetadataRoute } from 'next';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { getSettings } from '@/lib/services/settings';
import { getSiteUrl } from '@/lib/site-url-server';

export const revalidate = 86400; // 24 hours ISR — auto-refreshed daily

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  let siteUrl = '';
  try {
    const settings = await getSettings();
    siteUrl = await getSiteUrl(settings);
  } catch (e) {
    console.warn('Failed to load settings in sitemap:', e);
  }

  // 1. Fetch products and categories (incl. primary image for image sitemap)
  const { data: products } = await supabaseAdmin
    .from('products')
    .select('slug, updated_at, name, product_images(url, is_primary, sort_order)')
    .is('deleted_at', null)
    .eq('is_active', true);

  const { data: categories } = await supabaseAdmin
    .from('categories')
    .select('slug, updated_at')
    .eq('active', true);

  const { data: collections } = await supabaseAdmin
    .from('collections')
    .select('slug, updated_at')
    .eq('active', true);

  // 2. Base static routes (only indexable, canonical URLs — no wishlist/login/cart)
  const staticPages = [
    { path: '', priority: 1.0, freq: 'daily' as const },
    { path: '/shop', priority: 0.9, freq: 'daily' as const },
    { path: '/reviews', priority: 0.8, freq: 'daily' as const },
    { path: '/faq', priority: 0.5, freq: 'monthly' as const },
    { path: '/returns', priority: 0.5, freq: 'monthly' as const },
    { path: '/contact', priority: 0.5, freq: 'monthly' as const },
    { path: '/privacy-policy', priority: 0.3, freq: 'monthly' as const },
  ];

  const routes: MetadataRoute.Sitemap = staticPages.map((p) => ({
    url: `${siteUrl}${p.path}`,
    lastModified: new Date(),
    changeFrequency: p.freq,
    priority: p.priority,
  }));

  // 3. Add products
  if (products) {
    products.forEach((p) => {
      const row = p as { product_images?: Array<{ url?: string; is_primary?: boolean | null; sort_order?: number | null }> };
      const imgs = Array.isArray(row.product_images) ? row.product_images : [];
      const sorted = [...imgs].sort((a, b) => (b.is_primary ? 1 : 0) - (a.is_primary ? 1 : 0) || (a.sort_order ?? 0) - (b.sort_order ?? 0));
      const imageUrls = sorted
        .map((i) => i.url)
        .filter((u): u is string => typeof u === 'string' && u.length > 0)
        .slice(0, 5);
      routes.push({
        url: `${siteUrl}/product/${p.slug}`,
        lastModified: p.updated_at ? new Date(p.updated_at) : new Date(),
        changeFrequency: 'daily',
        priority: 0.7,
        ...(imageUrls.length ? { images: imageUrls } : {}),
      });
    });
  }

  // 4. Add categories (clean canonical /category/[slug] routes)
  if (categories) {
    categories.forEach((c) => {
      routes.push({
        url: `${siteUrl}/category/${c.slug}`,
        lastModified: c.updated_at ? new Date(c.updated_at) : new Date(),
        changeFrequency: 'weekly',
        priority: 0.8,
      });
    });
  }

  // 5. Add collections
  if (collections) {
    collections.forEach((c) => {
      routes.push({
        url: `${siteUrl}/shop?collection=${c.slug}`,
        lastModified: c.updated_at ? new Date(c.updated_at) : new Date(),
        changeFrequency: 'weekly',
        priority: 0.7,
      });
    });
  }

  return routes;
}
