'use client';

import React, { useState, useEffect, useRef } from 'react';
import { HomepageSection, StoreSettings, Product, Category, Review, Collection } from '@/lib/types';
import StoreFront from '@/components/store/StoreFront';
import Navbar from '@/components/common/Navbar';
import Footer from '@/components/common/Footer';
import MobileBottomNav from '@/components/common/MobileBottomNav';
import FloatingContacts from '@/components/common/FloatingContacts';
import CartBar from '@/components/store/CartBar';
import PremiumFeaturesProvider from '@/components/store/PremiumFeaturesProvider';
import ShopPage from '@/components/store/ShopPage';
import ThemeStyleRegistry from '@/components/common/ThemeStyleRegistry';
import { 
  StyleGuide, 
  useLiveProducts, 
  ProductPageBlocks 
} from './preview-client';

interface PreviewClientProps {
  initialSections: HomepageSection[];
  products: Product[];
  categories: Category[];
  collections?: Collection[];
  initialSettings: StoreSettings;
  reviews: Review[];
}

export default function PreviewClient({
  initialSections,
  products,
  categories,
  collections = [],
  initialSettings,
  reviews
}: PreviewClientProps) {
  const [sections, setSections] = useState<HomepageSection[]>(initialSections);
  const [settings, setSettings] = useState<StoreSettings>(initialSettings);
  const [activePage, setActivePage] = useState<'home' | 'shop' | 'product_detail' | 'product_card' | 'global' | 'appearance'>('home');
  const [productsList, setProductsList] = useState<Product[]>(products);
  const [activeProductSlug, setActiveProductSlug] = useState<string | null>(null);
  const [activeSectionId, setActiveSectionId] = useState<string | null>(null);
  const [viewportMode, setViewportMode] = useState<'desktop' | 'tablet' | 'mobile'>('mobile');

  const liveProducts = useLiveProducts(productsList, sections, settings);

  const currentProduct = React.useMemo(() => {
    const defaultProduct = liveProducts[0];
    if (!activeProductSlug) return defaultProduct;
    return liveProducts.find(p => p.slug === activeProductSlug) || defaultProduct;
  }, [liveProducts, activeProductSlug]);

  const lastScrolledSectionId = useRef<string | null>(null);

  // Hide Next.js dev overlays (the "N" button + "N Issue" badge) INSIDE the
  // preview iframe only — never touches the admin page itself.
  useEffect(() => {
    const style = document.createElement('style');
    style.setAttribute('data-preview-hide-dev', '');
    style.textContent = `
      nextjs-portal,
      [data-nextjs-dev-tools-button],
      [data-nextjs-toast],
      #__next-build-watcher,
      [data-next-badge-root],
      [data-next-badge] { display: none !important; visibility: hidden !important; }
    `;
    document.head.appendChild(style);
    return () => { style.remove(); };
  }, []);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data) {
        // Device viewport + safe-area insets from the customizer frame.
        if (event.data.type === 'VIEWPORT_WIDTH') {
          const root = document.documentElement;
          const top = Number(event.data.safeTop) || 0;
          const bottom = Number(event.data.safeBottom) || 0;
          try {
            root.style.setProperty('--preview-safe-top', `${top}px`);
            root.style.setProperty('--preview-safe-bottom', `${bottom}px`);
            // feed the storefront's existing bottom-overlay system so WhatsApp
            // button + sales toast sit above the home-indicator inset.
            root.style.setProperty('--safe-bottom', `${bottom}px`);
            if (event.data.mode) {
              root.setAttribute('data-device', event.data.mode);
              root.setAttribute('data-viewport-mode', event.data.mode);
            }
          } catch {}
          return;
        }
        if (event.data.type === 'sync') {
          if (event.data.viewportMode) {
            setViewportMode(event.data.viewportMode);
            try {
              document.documentElement.setAttribute('data-device', event.data.viewportMode);
              document.documentElement.setAttribute('data-viewport-mode', event.data.viewportMode);
            } catch {}
          }
          if (event.data.sections) {
            setSections(event.data.sections);
          }
          if (event.data.settings) {
            setSettings(event.data.settings);
          }
          if (event.data.products) {
            setProductsList(event.data.products);
          }
          if (event.data.activeProductSlug) {
            setActiveProductSlug(event.data.activeProductSlug);
          }
          if (event.data.activeSectionId !== undefined) {
            const nextActiveId = event.data.activeSectionId;
            setActiveSectionId(nextActiveId);
            if (nextActiveId && nextActiveId !== lastScrolledSectionId.current) {
              lastScrolledSectionId.current = nextActiveId;
              setTimeout(() => {
                const element = document.getElementById(nextActiveId);
                // Guard: node may have unmounted (page switch) before the timer
                // fires — scrolling a detached node throws parentNode errors.
                if (element && element.isConnected) {
                  element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
              }, 100);
            }
          }
        } else if (event.data.type === 'change_viewport') {
          if (event.data.viewportMode) {
            setViewportMode(event.data.viewportMode);
            try {
              document.documentElement.setAttribute('data-device', event.data.viewportMode);
              document.documentElement.setAttribute('data-viewport-mode', event.data.viewportMode);
            } catch {}
          }
        } else if (event.data.type === 'scroll_to_section') {
          lastScrolledSectionId.current = event.data.sectionId;
          const element = document.getElementById(event.data.sectionId);
          if (element && element.isConnected) {
            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        } else if (event.data.type === 'change_page') {
          setActivePage(event.data.page);
        }
      }
    };

    const handleLinkClick = (e: MouseEvent) => {
      let target = e.target as HTMLElement | null;
      let anchor: HTMLAnchorElement | null = null;
      let curr = target;
      while (curr) {
        if (curr.tagName === 'A') {
          anchor = curr as HTMLAnchorElement;
          break;
        }
        curr = curr.parentElement;
      }
      
      if (anchor) {
        const href = anchor.getAttribute('href');
        if (href) {
          const isRelative = href.startsWith('/') && !href.startsWith('//');
          const isSameDomain = href.startsWith(window.location.origin);
          
          if (isRelative || isSameDomain) {
            e.preventDefault();
            e.stopPropagation();
            
            const path = isRelative ? href : href.substring(window.location.origin.length);
            
            let page: 'home' | 'shop' | 'product_detail' | 'global' = 'home';
            if (path.startsWith('/product/')) {
              page = 'product_detail';
              const slug = path.replace('/product/', '').split('?')[0];
              setActiveProductSlug(slug);
            } else if (path.startsWith('/shop') || path === '/shop') {
              page = 'shop';
            } else if (path === '/' || path === '') {
              page = 'home';
            }
            
            setActivePage(page);
            window.parent.postMessage({ type: 'nav_to_page', page, href: path }, '*');
            return;
          }
        }
      }
      
      let button: HTMLButtonElement | null = null;
      curr = target;
      while (curr) {
        if (curr.tagName === 'BUTTON') {
          button = curr as HTMLButtonElement;
          break;
        }
        curr = curr.parentElement;
      }
      
      if (button) {
        const text = button.textContent?.toLowerCase() || '';
        if (text.includes('choose options') || text.includes('buy now')) {
          let card = button.parentElement;
          while (card && !card.getAttribute('href')) {
            card = card.parentElement;
          }
          if (card) {
            const href = card.getAttribute('href');
            if (href) {
              e.preventDefault();
              e.stopPropagation();
              
              let page: 'home' | 'shop' | 'product_detail' | 'global' = 'home';
              if (href.startsWith('/product/')) {
                page = 'product_detail';
                const slug = href.replace('/product/', '').split('?')[0];
                setActiveProductSlug(slug);
              }
              
              setActivePage(page);
              window.parent.postMessage({ type: 'nav_to_page', page, href }, '*');
            }
          }
        }
      }
    };

    window.addEventListener('message', handleMessage);
    document.addEventListener('click', handleLinkClick, true);
    window.parent.postMessage({ type: 'ready' }, '*');

    return () => {
      window.removeEventListener('message', handleMessage);
      document.removeEventListener('click', handleLinkClick, true);
    };
  }, []);

  return (
    <div className="flex min-h-screen flex-col bg-gray-50 dark:bg-[#0f0f1b] text-gray-900 dark:text-gray-100 pb-20 md:pb-0 transition-colors duration-200 w-full">
      <ThemeStyleRegistry settings={settings} />
      <Navbar settings={settings} storeName={settings?.store_name || 'Store'} logoUrl={settings?.logo_url} logoWidth={settings?.logo_width} />
      <main className="flex-grow bg-gray-50 dark:bg-[#0f0f1b] transition-colors duration-200 w-full overflow-x-clip">
        {(activePage === 'home' || activePage === 'global') && (
          <StoreFront
            initialProducts={liveProducts}
            categories={categories}
            collections={collections}
            settings={settings}
            reviews={reviews}
            sections={sections}
            isPreview={true}
            activeSectionId={activeSectionId}
            viewportMode={viewportMode}
          />
        )}
        {(activePage === 'shop' || activePage === 'product_card') && (
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
            <ShopPage
              initialProducts={liveProducts}
              categories={categories}
              settings={settings}
              isPreview={true}
            />
          </div>
        )}
        {activePage === 'product_detail' && liveProducts.length > 0 && (
          <ProductPageBlocks
            currentProduct={currentProduct}
            products={products}
            settings={settings}
          />
        )}
        {activePage === 'appearance' && (
          <StyleGuide settings={settings} products={liveProducts} />
        )}
      </main>
      <Footer settings={settings} />
      <CartBar currencySymbol={settings.currency_symbol} enabled={settings?.cart_bar_enabled !== false} />
      <MobileBottomNav
        enabled={settings?.mobile_bottom_nav_enabled !== false}
        items={settings?.mobile_bottom_nav_items}
        showLabels={settings?.mobile_bottom_nav_show_labels !== false}
      />
      <FloatingContacts settings={settings} />
      <PremiumFeaturesProvider settings={settings} />
    </div>
  );
}
