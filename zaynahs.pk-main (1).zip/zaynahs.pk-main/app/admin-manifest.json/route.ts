import { getSettings } from '@/lib/services/settings';

export const revalidate = 0; // Serve dynamically to ensure dynamic branding updates

/** Auto-detect MIME type from URL extension — prevents browser rejection */
const getIconType = (url: string): string => {
  const lower = url.toLowerCase().split('?')[0];
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.svg')) return 'image/svg+xml';
  if (lower.endsWith('.webp')) return 'image/webp';
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
  if (lower.endsWith('.gif')) return 'image/gif';
  if (lower.endsWith('.ico')) return 'image/x-icon';
  if (lower.includes('.supabase.co/storage')) return 'image/webp';
  return 'image/png';
};

export async function GET() {
  try {
    const settings = await getSettings();
    const brandName = settings.store_name || process.env.NEXT_PUBLIC_BRAND_NAME || 'Your Store';
    // Use only settings-driven URLs — /favicon.ico itself reads from settings dynamically
    const faviconUrl = settings.favicon_url || settings.logo_url || '/favicon.ico';
    const logoUrl = settings.logo_url || settings.favicon_url || '/favicon.ico';

    const manifestData = {
      id: '/admin',
      name: `${brandName} Admin`,
      short_name: `${brandName} Admin`,
      description: `${brandName} Admin Dashboard`,
      start_url: '/admin',
      scope: '/admin',
      display: 'standalone',
      background_color: '#0f0f1b',
      theme_color: '#1a1a2e',
      orientation: 'portrait',
      icons: [
        {
          src: faviconUrl,
          sizes: '192x192',
          type: getIconType(faviconUrl),
          purpose: 'any'
        },
        {
          src: faviconUrl,
          sizes: '192x192',
          type: getIconType(faviconUrl),
          purpose: 'maskable'
        },
        {
          src: logoUrl,
          sizes: '512x512',
          type: getIconType(logoUrl),
          purpose: 'any'
        },
        {
          src: logoUrl,
          sizes: '512x512',
          type: getIconType(logoUrl),
          purpose: 'maskable'
        }
      ]
    };

    return new Response(JSON.stringify(manifestData), {
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
      },
    });
  } catch (error) {
    console.error('Failed to generate dynamic admin manifest:', error);
    return new Response(JSON.stringify({}), { status: 500 });
  }
}

