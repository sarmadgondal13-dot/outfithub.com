import React, { cache } from 'react';
import { notFound } from 'next/navigation';
import ProductDetail from '@/components/store/ProductDetail';
import ProductReviews from '@/components/store/ProductReviews';
import ProductCard from '@/components/store/ProductCard';
import { getProducts, getProductBySlug, getRelatedProducts } from '@/lib/services/products';
import { getSettings } from '@/lib/services/settings';
import { getProductReviews, getAverageRating } from '@/lib/services/reviews';
import { getSocialProofCountForProduct } from '@/lib/services/social-proof';
import { Product } from '@/lib/types';
import { isFeatureEnabled } from '@/lib/features/premium';
import RecentlyViewed from '@/components/store/RecentlyViewed';
import SocialFeedRibbon from '@/components/store/SocialFeedRibbon';
import { getCatalogGridStyle, getContentWidthClass, CATALOG_SECTION_PADDING } from '@/lib/utils/responsiveGrid';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { cleanLocalhostUrls } from '@/lib/site-url';
import { getDomainBrand, cleanBrandName } from '@/lib/utils/getDomainBrand';
import { Metadata } from 'next';
import Breadcrumb from '@/components/Breadcrumb';

export const revalidate = 2592000; // 30 days ISR — webhooks purge instantly on admin save (RULE C10 / C12)
export const dynamicParams = true; // allow new slugs added after build

export async function generateStaticParams() {
  try {
    const products = await getProducts();
    return products.map((product) => ({ slug: product.slug }));
  } catch {
    return [];
  }
}

interface PageProps {
  params: Promise<{ slug: string }>;
}

const fetchProductSeoMeta = async (productId: string) => {
  const { data } = await supabaseAdmin
    .from('seo_meta')
    .select('*')
    .eq('entity_type', 'product')
    .eq('entity_id', productId)
    .maybeSingle();
  return data;
};

const getProductSeoMeta = cache(async (productId: string) => {
  if (typeof window !== 'undefined') return fetchProductSeoMeta(productId);
  try {
    const { unstable_cache } = await import('next/cache');
    const cachedFn = unstable_cache(
      () => fetchProductSeoMeta(productId),
      [`product-seo-meta-${productId}`],
      { revalidate: 2592000, tags: [`product-${productId}`, 'seo_meta'] }
    );
    return await cachedFn();
  } catch {
    return fetchProductSeoMeta(productId);
  }
});

function cleanMetaDescription(htmlText: string, siteUrl: string): string {
  if (!htmlText) return '';
  let text = cleanLocalhostUrls(htmlText, siteUrl);
  text = text.replace(/<[^>]*>/g, ' ');
  text = text
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/\s+/g, ' ')
    .trim();
  return text;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  try {
    const { slug } = await params;
    let decodedSlug = slug;
    try { decodedSlug = decodeURIComponent(slug); } catch {}

    const [brand, product, settings] = await Promise.all([
      getDomainBrand(),
      getProductBySlug(decodedSlug),
      getSettings()
    ]);
    if (!product) return {};

    const seoMeta = await getProductSeoMeta(product.id);
    const siteUrl = `${brand.protocol}://${brand.domain}`;

    const title = cleanBrandName(seoMeta?.seo_title, brand.name) || `${product.name} | ${brand.name}`;
    
    const rawDescription = cleanBrandName(seoMeta?.meta_description, brand.name) || cleanMetaDescription(product.description || '', siteUrl);
    const description = rawDescription.length > 160 ? `${rawDescription.slice(0, 157)}...` : rawDescription;

    const canonicalUrl = `${siteUrl}/product/${encodeURIComponent(decodedSlug)}`;
    const imageUrl = product.images?.[0]?.url 
      ? cleanLocalhostUrls(product.images[0].url, siteUrl) 
      : settings.logo_url || settings.favicon_url || '';

    return {
      metadataBase: new URL(siteUrl),
      title,
      description,
      keywords: seoMeta?.keywords ? seoMeta.keywords.split(',').map((k: string) => k.trim()) : (product.tags && product.tags.length > 0 ? product.tags : undefined),
      alternates: {
        canonical: canonicalUrl,
      },
      robots: {
        index: true,
        follow: true,
      },
      openGraph: {
        title: seoMeta?.og_title || title,
        description: seoMeta?.og_description || description,
        url: canonicalUrl,
        type: 'website', // NOTE: OpenGraph 'product' type below via product:* tags; keep 'website' for Next OG typing
        images: [{ url: imageUrl, width: 1200, height: 1200, alt: product.images?.[0]?.alt || product.name }],
      },
      twitter: {
        card: 'summary_large_image',
        title: seoMeta?.twitter_title || title,
        description: seoMeta?.twitter_description || description,
        images: [{ url: imageUrl, alt: product.images?.[0]?.alt || product.name }],
      },
      other: {
        'product:price:amount': product.price.toString(),
        'product:price:currency': 'PKR',
        'product:availability': product.stock > 0 ? 'in stock' : 'out of stock',
        'product:retailer_item_id': product.id,
      }
    };
  } catch {
    return {
      title: 'Product Details',
      description: 'View product details.',
    };
  }
}

export default async function ProductPage({ params }: PageProps) {
  const { slug } = await params;
  let decodedSlug = slug;
  try { decodedSlug = decodeURIComponent(slug); } catch {}
  
  const [product, settings, brand] = await Promise.all([
    getProductBySlug(decodedSlug),
    getSettings(),
    getDomainBrand()
  ]);

  if (!product) {
    notFound();
  }

  // Concurrent parallel execution for all secondary data
  const [seoMeta, reviews, averageRating, relatedProducts, socialProofCount] = await Promise.all([
    getProductSeoMeta(product.id),
    getProductReviews(product.id),
    getAverageRating(product.id),
    getRelatedProducts(product.id, product.category_id, 4),
    getSocialProofCountForProduct(product.id).catch(() => 0)
  ]);

  const hiddenBlocks = settings.product_page_hidden_blocks || [];
  const layout = (settings.product_page_layout || ['details', 'ticker', 'reviews', 'related', 'recently_viewed', 'social_feed'])
    .filter((b: string) => !hiddenBlocks.includes(b));

  const schemaBrandName = brand.name || settings?.store_name || 'Store';
  const siteUrl = settings?.store_url?.replace(/\/+$/, '') || `${brand.protocol}://${brand.domain}`;

  const productSchema: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": "Product",
    "name": product.name,
    "image": product.images?.map(i => cleanLocalhostUrls(i.url, siteUrl)) || [],
    "description": cleanMetaDescription(product.description || '', siteUrl),
    "sku": product.sku || product.id,
    "brand": {
      "@type": "Brand",
      "name": schemaBrandName
    },
    "offers": {
      "@type": "Offer",
      "price": product.price.toString(),
      "priceCurrency": "PKR",
      "itemCondition": "https://schema.org/NewCondition",
      "priceValidUntil": new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      "availability": product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      "url": `${siteUrl}/product/${slug}`,
      "shippingDetails": {
        "@type": "OfferShippingDetails",
        "shippingRate": {
          "@type": "MonetaryAmount",
          "value": "0",
          "currency": "PKR"
        },
        "shippingDestination": {
          "@type": "DefinedRegion",
          "addressCountry": "PK"
        },
        "deliveryTime": {
          "@type": "ShippingDeliveryTime",
          "handlingTime": { "@type": "QuantitativeValue", "minValue": 0, "maxValue": 1, "unitCode": "DAY" },
          "transitTime": { "@type": "QuantitativeValue", "minValue": 2, "maxValue": 5, "unitCode": "DAY" }
        }
      },
      "hasMerchantReturnPolicy": {
        "@type": "MerchantReturnPolicy",
        "applicableCountry": "PK",
        "returnPolicyCategory": "https://schema.org/MerchantReturnFiniteReturnWindow",
        "merchantReturnDays": 7,
        "returnMethod": "https://schema.org/ReturnByMail",
        "returnFees": "https://schema.org/FreeReturn"
      }
    }
  };

  const ratingCount =
    averageRating && averageRating.count > 0
      ? averageRating.count
      : (product.reviews_count || (reviews ? reviews.length : 0));
  const ratingVal =
    averageRating && averageRating.count > 0
      ? averageRating.average
      : (product.rating || 5.0);

  if (ratingCount > 0) {
    productSchema.aggregateRating = {
      "@type": "AggregateRating",
      "ratingValue": ratingVal.toFixed(1),
      "reviewCount": ratingCount.toString(),
      "bestRating": "5",
      "worstRating": "1"
    };
  }

  if (reviews && reviews.length > 0) {
    productSchema.review = reviews.slice(0, 10).map((r) => {
      const reviewImgs = Array.isArray(r.images) && r.images.length > 0 ? r.images : (r.screenshot_url ? [r.screenshot_url] : []);
      return {
        "@type": "Review",
        "author": {
          "@type": "Person",
          "name": r.customer_name || 'Customer'
        },
        "datePublished": r.created_at ? new Date(r.created_at).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
        "reviewBody": r.comment || '',
        "reviewRating": {
          "@type": "Rating",
          "ratingValue": r.rating.toString(),
          "bestRating": "5",
          "worstRating": "1"
        },
        ...(reviewImgs.length > 0 && {
          "image": reviewImgs[0]
        })
      };
    });
  }

  const faqSchema = seoMeta?.faq_schema && Array.isArray(seoMeta.faq_schema) && seoMeta.faq_schema.length > 0 ? {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": (seoMeta.faq_schema as Array<{ q: string; a: string }>).map((item) => ({
      "@type": "Question",
      "name": item.q,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": item.a
      }
    }))
  } : null;

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema) }}
      />
      {faqSchema && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
        />
      )}

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-4">
        <Breadcrumb
          siteUrl={siteUrl}
          items={[
            ...(product.category ? [{ label: product.category.name, href: `/shop?category=${product.category.slug}` }] : []),
            { label: product.name, href: `/product/${slug}` }
          ]}
        />
      </div>

      <div className="space-y-10 pb-16">
        {layout.map((block: string) => {
          if (block === 'details') {
            return (
              <ProductDetail key="details" product={product} settings={settings} averageRating={averageRating} socialProofCount={socialProofCount ?? 0} />
            );
          }
          if (block === 'ticker') {
            if (!settings.product_detail_enable_ticker || !settings.product_detail_ticker_text) return null;
            return (
              <div key="ticker" className="w-full overflow-hidden bg-gray-50 dark:bg-white/5 border-y border-gray-200 dark:border-gray-800 py-3.5 select-none relative">
                <style>{`
                  @keyframes marquee {
                    0% { transform: translateX(0); }
                    100% { transform: translateX(-50%); }
                  }
                  .animate-marquee-infinite {
                    display: flex;
                    width: max-content;
                    animation: marquee 30s linear infinite;
                  }
                  .animate-marquee-infinite:hover {
                    animation-play-state: paused;
                  }
                `}</style>
                
                <div className="animate-marquee-infinite flex items-center whitespace-nowrap gap-8">
                  {[...Array(4)].map((_, loopIdx) => (
                    <div key={loopIdx} className="flex items-center gap-8">
                      {settings.product_detail_ticker_text.split('\n').filter(Boolean).map((item: string, itemIdx: number) => (
                        <div key={itemIdx} className="flex items-center gap-8 text-sm font-bold text-gray-850 dark:text-gray-200 uppercase tracking-wider">
                          <span>{item}</span>
                          <span className="text-gray-400 dark:text-gray-600 font-normal">✦</span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            );
          }
          if (block === 'reviews') {
            return (
              <div key="reviews" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <ProductReviews product={product} reviews={reviews} averageRating={averageRating} socialProofCount={socialProofCount ?? 0} />
              </div>
            );
          }
          if (block === 'related') {
            if (!isFeatureEnabled(settings, 'related_products') || relatedProducts.length === 0) return null;
            const relatedGrid = getCatalogGridStyle({
              mode: settings.related_columns_mode || 'manual',
              mobile: settings.related_columns_mobile || 2,
              tablet: settings.related_columns_tablet || 3,
              desktop: settings.related_columns_desktop || 4,
              wide: settings.related_columns_wide,
              minDesktop: settings.related_min_card_desktop,
              gap: settings.related_grid_gap,
            });
            const displayRelated = relatedProducts.slice(0, settings.related_products_limit || 4);

            return (
              <div key="related" className={`mx-auto ${getContentWidthClass(settings.related_content_width)} ${CATALOG_SECTION_PADDING} border-t border-gray-200 dark:border-gray-800 pt-10`}>
                <div className="text-center md:text-left mb-8">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                    {settings.related_products_title || 'Related Products'}
                  </h3>
                  <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mt-1">
                    {settings.related_products_subtitle || 'You might also like these handpicked recommendations'}
                  </p>
                </div>
                <div className={relatedGrid.className} data-mode={relatedGrid.mode} style={relatedGrid.style}>
                  {displayRelated.map((prod: Product) => (
                    <ProductCard key={prod.id} product={prod} currencySymbol={settings.currency_symbol} settings={settings} />
                  ))}
                </div>
              </div>
            );
          }
          if (block === 'recently_viewed') {
            return (
              <RecentlyViewed 
                key="recently_viewed" 
                settings={settings} 
                currentProductId={product.id} 
              />
            );
          }
          if (block === 'social_feed') {
            return (
              <SocialFeedRibbon 
                key="social_feed" 
                settings={settings} 
              />
            );
          }
          return null;
        })}
      </div>
    </>
  );
}
