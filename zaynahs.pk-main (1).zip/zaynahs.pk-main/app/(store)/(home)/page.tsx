import React from 'react';
import StoreFront from '@/components/store/StoreFront';
import { getProducts } from '@/lib/services/products';
import { getCategories } from '@/lib/services/categories';
import { getCollections } from '@/lib/services/collections';
import { getSettings } from '@/lib/services/settings';
import { getTopReviews, getTotalReviewsStats } from '@/lib/services/reviews';
import { getHomepageSections } from '@/lib/services/sections';
import { getActiveSocialProofCount } from '@/lib/services/social-proof';
import { getDomainBrand } from '@/lib/utils/getDomainBrand';
import { Metadata } from 'next';

export const revalidate = 2592000; // 30 days ISR — webhooks purge instantly on admin save (RULE C10 / C12)

export async function generateMetadata(): Promise<Metadata> {
  try {
    const settings = await getSettings();
    const brandName = settings.store_name || process.env.NEXT_PUBLIC_BRAND_NAME || 'Store';
    const brandTagline = settings.tagline || process.env.NEXT_PUBLIC_BRAND_TAGLINE || '';
    const siteUrl = settings?.store_url?.replace(/\/+$/, '') || process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

    const banner = settings.banner_url || settings.logo_url || settings.favicon_url || '';
    const title = settings.meta_title || (brandTagline ? `${brandName} - ${brandTagline}` : brandName);
    const desc = (settings.meta_description || brandTagline).slice(0, 160);

    return {
      metadataBase: new URL(siteUrl),
      title: {
        absolute: title
      },
      description: desc,
      alternates: { canonical: siteUrl },
      other: {
        'og:locale': 'en_US',
      },
      openGraph: {
        title: title,
        description: desc,
        url: siteUrl,
        siteName: brandName,
        type: 'website',
        locale: 'en_US',
        images: [{ url: banner, width: 1200, height: 630, alt: brandName }],
      },
      twitter: {
        card: 'summary_large_image',
        title: title,
        description: desc,
        images: [banner],
        site: settings.twitter_handle || process.env.NEXT_PUBLIC_TWITTER_HANDLE || '',
        creator: settings.twitter_handle || process.env.NEXT_PUBLIC_TWITTER_HANDLE || '',
      }
    };
  } catch {
    return {
      title: 'Store',
      description: 'Premium online store.',
      openGraph: {
        type: 'website',
        title: 'Store',
        description: 'Premium online store.',
        images: [{ url: '/favicon.ico' }],
      },
      twitter: {
        card: 'summary_large_image',
        title: 'Store',
        description: 'Premium online store.',
        images: ['/favicon.ico'],
      }
    };
  }
}

export default async function CatalogPage() {
  // Fetch all active products on SSR to prevent layout shifts and missing products in Featured/Category grids.
  // The data is cached via unstable_cache in getProducts, so DB load is 0.
  const [products, categories, collections, settings, reviews, sections, socialProofCount, reviewStats] = await Promise.all([
    getProducts(),
    getCategories(),
    getCollections(),
    getSettings(),
    getTopReviews(8),
    getHomepageSections(true),
    getActiveSocialProofCount().catch(() => 0),
    getTotalReviewsStats().catch(() => ({ totalCount: 0, avgRating: 5.0 }))
  ]);

  return (
    <StoreFront
      initialProducts={products}
      categories={categories}
      collections={collections}
      settings={settings}
      reviews={reviews}
      sections={sections}
      socialProofCount={socialProofCount}
      totalReviewsCount={reviewStats.totalCount}
      avgStoreRating={reviewStats.avgRating}
    />
  );
}
