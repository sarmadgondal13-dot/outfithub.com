import React, { Suspense } from 'react';
import Navbar from '@/components/common/Navbar';
import CartBar from '@/components/store/CartBar';
import Footer from '@/components/common/Footer';
import MobileBottomNav from '@/components/common/MobileBottomNav';
import FloatingContacts from '@/components/common/FloatingContacts';
import PremiumFeaturesProvider from '@/components/store/PremiumFeaturesProvider';
import ScrollRestorer from '@/components/store/ScrollRestorer';
import TrafficBeacon from '@/components/store/TrafficBeacon';
import { getSettings } from '@/lib/services/settings';
import { getDomainBrand } from '@/lib/utils/getDomainBrand';

export default async function StoreLayout({
  children
}: {
  children: React.ReactNode;
}) {
  const [settings, brand] = await Promise.all([
    getSettings(),
    getDomainBrand().catch(() => null)
  ]);
  const brandName = brand?.name ?? settings.store_name;

  return (
    <div className="flex min-h-screen flex-col bg-gray-50 dark:bg-[#0f0f1b] text-gray-900 dark:text-gray-100 pb-36 md:pb-0 transition-colors duration-200">
      <Suspense fallback={null}>
        <ScrollRestorer />
      </Suspense>
      <Suspense fallback={null}>
        <TrafficBeacon />
      </Suspense>
      <Suspense fallback={<div className="h-16 bg-white dark:bg-[#0f0f1b] border-b border-gray-200 dark:border-gray-800" />}>
        <Navbar settings={settings} storeName={brandName} logoUrl={settings?.logo_url} logoWidth={settings?.logo_width} />
      </Suspense>
      <main className="flex-grow min-h-[80vh] bg-gray-50 dark:bg-[#0f0f1b] transition-colors duration-200 overflow-x-clip">

        {children}
      </main>
      <Footer settings={settings} brandName={brandName} />
      <CartBar currencySymbol={settings.currency_symbol} enabled={settings?.cart_bar_enabled !== false} />
      <MobileBottomNav
        enabled={settings?.mobile_bottom_nav_enabled !== false}
        items={settings?.mobile_bottom_nav_items}
        showLabels={settings?.mobile_bottom_nav_show_labels !== false}
      />
      <FloatingContacts settings={settings} />
      <PremiumFeaturesProvider settings={settings} />
    </div>
  );
}
